
-- Enums
CREATE TYPE public.app_role AS ENUM ('admin','principal','teacher','student','parent','pending');
CREATE TYPE public.user_status AS ENUM ('pending','approved','rejected');
CREATE TYPE public.identifier_type AS ENUM ('roll','phone','email');
CREATE TYPE public.link_status AS ENUM ('pending','approved','rejected');

-- Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  identifier TEXT NOT NULL,
  identifier_type public.identifier_type NOT NULL,
  status public.user_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX profiles_identifier_unique ON public.profiles(identifier_type, identifier);

-- User roles
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Security definer role check
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role=_role);
$$;

CREATE OR REPLACE FUNCTION public.current_status() RETURNS public.user_status
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT status FROM public.profiles WHERE id = auth.uid();
$$;

CREATE OR REPLACE FUNCTION public.is_staff(_user_id UUID) RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role IN ('admin','principal','teacher'));
$$;

-- Handle new user: first user = admin/approved, else pending
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  is_first BOOLEAN;
  v_name TEXT := COALESCE(NEW.raw_user_meta_data->>'name', NEW.email);
  v_identifier TEXT := COALESCE(NEW.raw_user_meta_data->>'identifier', NEW.email);
  v_id_type public.identifier_type := COALESCE((NEW.raw_user_meta_data->>'identifier_type')::public.identifier_type, 'email');
  v_signup_role public.app_role := COALESCE((NEW.raw_user_meta_data->>'signup_role')::public.app_role, 'pending');
BEGIN
  SELECT NOT EXISTS(SELECT 1 FROM public.profiles) INTO is_first;
  IF is_first THEN
    INSERT INTO public.profiles(id, name, identifier, identifier_type, status)
      VALUES (NEW.id, v_name, v_identifier, v_id_type, 'approved');
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.profiles(id, name, identifier, identifier_type, status)
      VALUES (NEW.id, v_name, v_identifier, v_id_type, 'pending');
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, 'pending');
    -- store desired role separately so admin can promote
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, v_signup_role) ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Domain tables
CREATE TABLE public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  roll_number TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  class TEXT NOT NULL,
  section TEXT NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.parent_child_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  roll_number TEXT NOT NULL,
  status public.link_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(parent_id, roll_number)
);

CREATE TABLE public.attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  present BOOLEAN NOT NULL DEFAULT true,
  marked_by UUID REFERENCES auth.users(id),
  UNIQUE(student_id, date)
);

CREATE TABLE public.homework (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class TEXT NOT NULL, section TEXT NOT NULL,
  subject TEXT NOT NULL, title TEXT NOT NULL, description TEXT,
  due_date DATE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.homework_completion (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  homework_id UUID NOT NULL REFERENCES public.homework(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  completed BOOLEAN NOT NULL DEFAULT true,
  completed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(homework_id, student_id)
);

CREATE TABLE public.marks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  subject TEXT NOT NULL, exam TEXT NOT NULL,
  score NUMERIC NOT NULL, max_score NUMERIC NOT NULL DEFAULT 100,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.remarks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  remark TEXT NOT NULL,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.exams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class TEXT NOT NULL, section TEXT,
  subject TEXT NOT NULL, exam_date DATE NOT NULL,
  start_time TIME, notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Transport
CREATE TABLE public.routes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_name TEXT NOT NULL,
  toll_cost NUMERIC NOT NULL DEFAULT 0
);
CREATE TABLE public.buses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  internal_bus_number TEXT NOT NULL UNIQUE,
  number_plate TEXT NOT NULL,
  driver TEXT,
  route_id UUID REFERENCES public.routes(id) ON DELETE SET NULL
);
CREATE TABLE public.bus_km_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID NOT NULL REFERENCES public.buses(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  opening_km NUMERIC NOT NULL,
  closing_km NUMERIC NOT NULL,
  distance NUMERIC GENERATED ALWAYS AS (closing_km - opening_km) STORED
);
CREATE TABLE public.fuel_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID NOT NULL REFERENCES public.buses(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  litres NUMERIC NOT NULL, cost NUMERIC NOT NULL
);
CREATE TABLE public.fastag_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID NOT NULL UNIQUE REFERENCES public.buses(id) ON DELETE CASCADE,
  current_balance NUMERIC NOT NULL DEFAULT 0
);
CREATE TABLE public.fastag_recharges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID NOT NULL REFERENCES public.buses(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE
);
CREATE TABLE public.bus_arrivals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID NOT NULL REFERENCES public.buses(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  arrival_time TIME NOT NULL,
  rank INT,
  UNIQUE(bus_id, date)
);

-- EB
CREATE TABLE public.eb_readings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meter TEXT NOT NULL CHECK (meter IN ('school','college')),
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  reading NUMERIC NOT NULL,
  units NUMERIC
);

-- Kitchen
CREATE TABLE public.kitchen_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  stock NUMERIC NOT NULL DEFAULT 0,
  unit TEXT NOT NULL DEFAULT 'kg'
);
CREATE TABLE public.kitchen_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID REFERENCES public.kitchen_items(id) ON DELETE SET NULL,
  item_name TEXT NOT NULL,
  qty NUMERIC NOT NULL, cost NUMERIC NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE
);
CREATE TABLE public.gas_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  cylinders NUMERIC NOT NULL,
  cost NUMERIC NOT NULL
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parent_child_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.homework ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.homework_completion ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.marks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.remarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.routes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.buses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bus_km_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fuel_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fastag_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fastag_recharges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bus_arrivals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.eb_readings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kitchen_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kitchen_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gas_logs ENABLE ROW LEVEL SECURITY;

-- Policies: profiles
CREATE POLICY "self read profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "staff read profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'));
CREATE POLICY "admin update profile" ON public.profiles FOR UPDATE USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "self update profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- user_roles
CREATE POLICY "self read roles" ON public.user_roles FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "admin all roles" ON public.user_roles FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "principal read roles" ON public.user_roles FOR SELECT USING (public.has_role(auth.uid(),'principal'));

-- Helper: approved + role check macro via policies
-- students
CREATE POLICY "approved read students" ON public.students FOR SELECT USING (public.current_status()='approved');
CREATE POLICY "staff write students" ON public.students FOR ALL USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

-- parent_child_links
CREATE POLICY "parent read own links" ON public.parent_child_links FOR SELECT USING (parent_id = auth.uid() OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'));
CREATE POLICY "parent insert own link" ON public.parent_child_links FOR INSERT WITH CHECK (parent_id = auth.uid());
CREATE POLICY "admin manage links" ON public.parent_child_links FOR ALL USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Academic tables
CREATE POLICY "approved read attendance" ON public.attendance FOR SELECT USING (public.current_status()='approved');
CREATE POLICY "staff write attendance" ON public.attendance FOR ALL USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

CREATE POLICY "approved read homework" ON public.homework FOR SELECT USING (public.current_status()='approved');
CREATE POLICY "staff write homework" ON public.homework FOR ALL USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

CREATE POLICY "approved read hw completion" ON public.homework_completion FOR SELECT USING (public.current_status()='approved');
CREATE POLICY "user write own hw completion" ON public.homework_completion FOR ALL USING (public.current_status()='approved') WITH CHECK (public.current_status()='approved');

CREATE POLICY "approved read marks" ON public.marks FOR SELECT USING (public.current_status()='approved');
CREATE POLICY "staff write marks" ON public.marks FOR ALL USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

CREATE POLICY "approved read remarks" ON public.remarks FOR SELECT USING (public.current_status()='approved');
CREATE POLICY "staff write remarks" ON public.remarks FOR ALL USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

CREATE POLICY "approved read exams" ON public.exams FOR SELECT USING (public.current_status()='approved');
CREATE POLICY "staff write exams" ON public.exams FOR ALL USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

-- Transport / EB / Kitchen: admin + principal only (principal read)
DO $$ DECLARE t TEXT;
BEGIN
  FOR t IN SELECT unnest(ARRAY['routes','buses','bus_km_logs','fuel_logs','fastag_accounts','fastag_recharges','bus_arrivals','eb_readings','kitchen_items','kitchen_purchases','gas_logs']) LOOP
    EXECUTE format('CREATE POLICY "admin_all_%1$s" ON public.%1$s FOR ALL USING (public.has_role(auth.uid(),''admin'')) WITH CHECK (public.has_role(auth.uid(),''admin''));', t);
    EXECUTE format('CREATE POLICY "principal_read_%1$s" ON public.%1$s FOR SELECT USING (public.has_role(auth.uid(),''principal''));', t);
  END LOOP;
END $$;
