
-- Enquiries
CREATE TABLE public.enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  standard text NOT NULL,
  contact text,
  remarks text,
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.enquiries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage enquiries" ON public.enquiries FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'));
CREATE POLICY "chairman view enquiries" ON public.enquiries FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'chairman'));

-- Fees
CREATE TABLE public.fees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_name text NOT NULL,
  class text NOT NULL,
  phone text,
  term1_fee numeric NOT NULL DEFAULT 0,
  total_paid numeric NOT NULL DEFAULT 0,
  remarks text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.fees ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage fees" ON public.fees FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'));
CREATE POLICY "chairman view fees" ON public.fees FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'chairman'));

-- Stock items
CREATE TABLE public.stock_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL CHECK (category IN ('stationary','sports')),
  name text NOT NULL,
  quantity numeric NOT NULL DEFAULT 0,
  unit text DEFAULT 'pcs',
  remarks text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.stock_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage stock" ON public.stock_items FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'));
CREATE POLICY "chairman view stock" ON public.stock_items FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'chairman'));

-- Staff attendance category
ALTER TABLE public.staff_attendance ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'office';
