
-- EB readings: add serial_no + remarks
ALTER TABLE public.eb_readings ADD COLUMN IF NOT EXISTS serial_no SERIAL;
ALTER TABLE public.eb_readings ADD COLUMN IF NOT EXISTS remarks TEXT;

-- Bus KM register: extra columns
ALTER TABLE public.bus_km_logs ADD COLUMN IF NOT EXISTS diesel_litres NUMERIC;
ALTER TABLE public.bus_km_logs ADD COLUMN IF NOT EXISTS mileage NUMERIC;
ALTER TABLE public.bus_km_logs ADD COLUMN IF NOT EXISTS amount NUMERIC;
ALTER TABLE public.bus_km_logs ADD COLUMN IF NOT EXISTS bill_image TEXT;

-- Bus arrivals: add place/route + km
ALTER TABLE public.bus_arrivals ADD COLUMN IF NOT EXISTS place_route TEXT;
ALTER TABLE public.bus_arrivals ADD COLUMN IF NOT EXISTS km NUMERIC;

-- Homework completion proof
ALTER TABLE public.homework_completion ADD COLUMN IF NOT EXISTS proof_url TEXT;

-- Bus Maintenance register
CREATE TABLE IF NOT EXISTS public.bus_maintenance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  serial_no SERIAL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  bus_id UUID,
  vendor_name TEXT NOT NULL,
  item_description TEXT NOT NULL,
  bill_no TEXT,
  amount NUMERIC NOT NULL DEFAULT 0,
  remarks TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.bus_maintenance ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin_all_maint" ON public.bus_maintenance FOR ALL USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "principal_read_maint" ON public.bus_maintenance FOR SELECT USING (has_role(auth.uid(),'principal'));

-- Fitness Certificates (FC) for buses
CREATE TABLE IF NOT EXISTS public.fitness_certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bus_id UUID NOT NULL,
  fc_number TEXT,
  issue_date DATE,
  expiry_date DATE NOT NULL,
  image_url TEXT,
  remarks TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.fitness_certificates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin_all_fc" ON public.fitness_certificates FOR ALL USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "principal_read_fc" ON public.fitness_certificates FOR SELECT USING (has_role(auth.uid(),'principal'));

-- Storage bucket for uploads (bill pics, hw proofs, FC scans)
INSERT INTO storage.buckets (id, name, public) VALUES ('svm-uploads','svm-uploads', true) ON CONFLICT (id) DO NOTHING;
CREATE POLICY "svm public read" ON storage.objects FOR SELECT USING (bucket_id='svm-uploads');
CREATE POLICY "svm authenticated upload" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id='svm-uploads');
CREATE POLICY "svm owner update" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id='svm-uploads' AND owner = auth.uid());
CREATE POLICY "svm owner delete" ON storage.objects FOR DELETE TO authenticated USING (bucket_id='svm-uploads' AND owner = auth.uid());
