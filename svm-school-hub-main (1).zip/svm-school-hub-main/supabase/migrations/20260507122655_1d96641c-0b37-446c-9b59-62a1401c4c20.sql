
CREATE TABLE IF NOT EXISTS public.admissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admission_date date NOT NULL DEFAULT CURRENT_DATE,
  student_name text NOT NULL,
  grade text NOT NULL,
  parent_name text,
  contact text,
  remarks text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.admissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin_all_admissions" ON public.admissions FOR ALL
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "principal_read_admissions" ON public.admissions FOR SELECT
  USING (has_role(auth.uid(),'principal'));
CREATE POLICY "chairman_read_admissions" ON public.admissions FOR SELECT
  USING (has_role(auth.uid(),'chairman'));

-- Allow chairman read-access to operational data tables (read-only reports)
CREATE POLICY "chairman_read_students" ON public.students FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_attendance" ON public.attendance FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_marks" ON public.marks FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_homework" ON public.homework FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_exams" ON public.exams FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_buses" ON public.buses FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_routes" ON public.routes FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_bus_km_logs" ON public.bus_km_logs FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_fuel_logs" ON public.fuel_logs FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_fastag_accounts" ON public.fastag_accounts FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_fastag_recharges" ON public.fastag_recharges FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_bus_arrivals" ON public.bus_arrivals FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_bus_maintenance" ON public.bus_maintenance FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_fitness_certificates" ON public.fitness_certificates FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_eb_readings" ON public.eb_readings FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_kitchen_items" ON public.kitchen_items FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_kitchen_purchases" ON public.kitchen_purchases FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_gas_logs" ON public.gas_logs FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_teacher_attendance" ON public.teacher_attendance FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_staff_attendance" ON public.staff_attendance FOR SELECT USING (has_role(auth.uid(),'chairman'));
CREATE POLICY "chairman_read_admissions_extra" ON public.admissions FOR SELECT USING (has_role(auth.uid(),'chairman'));
