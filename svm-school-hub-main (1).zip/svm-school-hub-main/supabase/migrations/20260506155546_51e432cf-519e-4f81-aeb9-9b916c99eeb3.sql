
-- Teacher attendance
CREATE TABLE public.teacher_attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id uuid NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  in_time time,
  out_time time,
  status text NOT NULL DEFAULT 'Present',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (teacher_id, date)
);
ALTER TABLE public.teacher_attendance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admin all teacher_att" ON public.teacher_attendance
  FOR ALL USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "principal read teacher_att" ON public.teacher_attendance
  FOR SELECT USING (has_role(auth.uid(),'principal'));
CREATE POLICY "teacher own teacher_att read" ON public.teacher_attendance
  FOR SELECT USING (teacher_id = auth.uid());
CREATE POLICY "teacher own teacher_att insert" ON public.teacher_attendance
  FOR INSERT WITH CHECK (teacher_id = auth.uid() AND has_role(auth.uid(),'teacher'));
CREATE POLICY "teacher own teacher_att update" ON public.teacher_attendance
  FOR UPDATE USING (teacher_id = auth.uid() AND has_role(auth.uid(),'teacher'));

-- Staff attendance (office staff, no auth account required)
CREATE TABLE public.staff_attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_name text NOT NULL,
  role text,
  date date NOT NULL DEFAULT CURRENT_DATE,
  in_time time,
  out_time time,
  status text NOT NULL DEFAULT 'Present',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.staff_attendance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admin all staff_att" ON public.staff_attendance
  FOR ALL USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "principal read staff_att" ON public.staff_attendance
  FOR SELECT USING (has_role(auth.uid(),'principal'));

-- Add odometer + bill_image to fuel_logs
ALTER TABLE public.fuel_logs
  ADD COLUMN IF NOT EXISTS odometer numeric,
  ADD COLUMN IF NOT EXISTS bill_image text;
