import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { StatCard } from "@/components/StatCard";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BrandLogo } from "@/components/BrandLogo";
import {
  Users, GraduationCap, Bus, Fuel, Zap, ChefHat, ClipboardCheck,
  TrendingUp, AlertTriangle, UserPlus,
} from "lucide-react";
import { format, subDays } from "date-fns";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";

export default function Chairman() {
  const [from, setFrom] = useState(format(subDays(new Date(), 30), "yyyy-MM-dd"));
  const [to, setTo] = useState(format(new Date(), "yyyy-MM-dd"));
  const [s, setS] = useState<any>({});
  const [trend, setTrend] = useState<any[]>([]);
  const [busPerf, setBusPerf] = useState<any[]>([]);
  const [admissionsByGrade, setAbg] = useState<any[]>([]);
  const [recentAdmissions, setRecent] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const today = format(new Date(), "yyyy-MM-dd");
      const [students, attToday, exams, buses, fuel, eb, kitchen, teacherAtt, staffAtt, admissions] = await Promise.all([
        supabase.from("students").select("id,class", { count: "exact" }),
        supabase.from("attendance").select("present", { count: "exact" }).eq("date", today),
        supabase.from("exams").select("id,exam_date,subject").gte("exam_date", today).order("exam_date").limit(5),
        supabase.from("buses").select("id,internal_bus_number"),
        supabase.from("fuel_logs").select("cost,litres,bus_id,date").gte("date", from).lte("date", to),
        supabase.from("eb_readings").select("units,date").gte("date", from).lte("date", to),
        supabase.from("kitchen_items").select("name,stock"),
        supabase.from("teacher_attendance").select("id,status").eq("date", today),
        supabase.from("staff_attendance").select("id,status").eq("date", today),
        supabase.from("admissions").select("*").gte("admission_date", from).lte("admission_date", to).order("admission_date", { ascending: false }),
      ]);
      const present = (attToday.data ?? []).filter((a: any) => a.present).length;
      const total = attToday.count ?? 0;
      const pct = total ? Math.round((present / total) * 100) : 0;
      const fuelCost = (fuel.data ?? []).reduce((a: number, f: any) => a + Number(f.cost || 0), 0);
      const ebUnits = (eb.data ?? []).reduce((a: number, r: any) => a + Number(r.units || 0), 0);

      setS({
        students: students.count ?? 0,
        attendancePct: pct,
        teachersPresent: (teacherAtt.data ?? []).filter((t: any) => t.status === "Present").length,
        staffPresent: (staffAtt.data ?? []).filter((t: any) => t.status === "Present").length,
        buses: (buses.data ?? []).length,
        fuelCost,
        ebUnits,
        kitchenItems: (kitchen.data ?? []).length,
        admissionsRange: (admissions.data ?? []).length,
        upcomingExams: exams.data ?? [],
      });

      // attendance trend across the selected range (cap to ~30 days for display)
      const fromD = new Date(from); const toD = new Date(to);
      const rangeDays = Math.min(60, Math.max(1, Math.round((toD.getTime() - fromD.getTime()) / 86400000) + 1));
      const days = Array.from({ length: rangeDays }, (_, i) => format(subDays(toD, rangeDays - 1 - i), "yyyy-MM-dd"));
      const { data: weekAtt } = await supabase.from("attendance").select("date,present").in("date", days);
      const map: Record<string, { p: number; t: number }> = {};
      days.forEach(d => map[d] = { p: 0, t: 0 });
      (weekAtt ?? []).forEach((r: any) => { if (map[r.date]) { map[r.date].t++; if (r.present) map[r.date].p++; } });
      setTrend(days.map(d => ({ day: format(new Date(d), "d MMM"), attendance: map[d].t ? Math.round(map[d].p / map[d].t * 100) : 0 })));

      const byBus: Record<string, number> = {};
      (fuel.data ?? []).forEach((f: any) => { byBus[f.bus_id] = (byBus[f.bus_id] ?? 0) + Number(f.cost || 0); });
      setBusPerf((buses.data ?? []).map((b: any) => ({ bus: `#${b.internal_bus_number}`, cost: Math.round(byBus[b.id] ?? 0) })));

      const byGrade: Record<string, number> = {};
      (admissions.data ?? []).forEach((a: any) => { byGrade[a.grade] = (byGrade[a.grade] ?? 0) + 1; });
      setAbg(Object.entries(byGrade).map(([grade, count]) => ({ grade, count })));
      setRecent((admissions.data ?? []).slice(0, 8));
    })();
  }, [from, to]);

  return (
    <div className="space-y-6">
      <div className="w-full rounded-2xl bg-gradient-to-r from-primary/10 via-card to-card border overflow-hidden">
        <div className="w-full bg-white py-6 flex items-center justify-center">
          <BrandLogo className="h-24 w-auto max-w-full" />
        </div>
        <div className="p-4 lg:p-5 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-xl lg:text-2xl font-bold">Chairman Report</h1>
            <p className="text-muted-foreground text-sm">Read-only overview · {format(new Date(), "EEEE, MMM d, yyyy")}</p>
          </div>
          <div className="flex flex-wrap gap-2 items-center bg-card/60 backdrop-blur p-2 rounded-xl border">
            <span className="text-xs text-muted-foreground px-1">Range</span>
            <Input type="date" value={from} onChange={e => setFrom(e.target.value)} className="w-auto h-8" />
            <span className="text-muted-foreground text-xs">to</span>
            <Input type="date" value={to} onChange={e => setTo(e.target.value)} className="w-auto h-8" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total Students" value={s.students ?? 0} icon={Users} variant="primary" />
        <StatCard label="Today Attendance" value={`${s.attendancePct ?? 0}%`} icon={TrendingUp} variant="success" />
        <StatCard label="Admissions (range)" value={s.admissionsRange ?? 0} icon={UserPlus} />
        <StatCard label="Teachers Present" value={s.teachersPresent ?? 0} icon={ClipboardCheck} />
        <StatCard label="Staff Present" value={s.staffPresent ?? 0} icon={ClipboardCheck} />
        <StatCard label="Buses" value={s.buses ?? 0} icon={Bus} />
        <StatCard label="Fuel (range)" value={`₹${(s.fuelCost ?? 0).toLocaleString()}`} icon={Fuel} variant="warning" />
        <StatCard label="EB Units (range)" value={(s.ebUnits ?? 0).toFixed(0)} icon={Zap} />
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="transport">Transport</TabsTrigger>
          <TabsTrigger value="admissions">Admissions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 mt-4">
          <Card className="card-modern p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Attendance Trend</h3>
              <Badge variant="secondary">14 days</Badge>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trend}>
                  <defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient></defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }} />
                  <Area type="monotone" dataKey="attendance" stroke="hsl(var(--primary))" fill="url(#g1)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="card-modern p-5">
            <h3 className="font-semibold mb-3">Upcoming Exams</h3>
            {(s.upcomingExams ?? []).length === 0 && <p className="text-sm text-muted-foreground">None scheduled</p>}
            <div className="space-y-2">
              {(s.upcomingExams ?? []).map((e: any) => (
                <div key={e.id} className="p-3 rounded-xl bg-muted/40 flex justify-between text-sm">
                  <span className="font-medium">{e.subject}</span>
                  <Badge variant="outline">{e.exam_date}</Badge>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="transport" className="space-y-4 mt-4">
          <Card className="card-modern p-5">
            <h3 className="font-semibold mb-3">Fuel Cost per Bus (30d)</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={busPerf}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="bus" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }} />
                  <Bar dataKey="cost" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="admissions" className="space-y-4 mt-4">
          <Card className="card-modern p-5">
            <h3 className="font-semibold mb-3">Admissions by Grade</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={admissionsByGrade}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="grade" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }} />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <Card className="card-modern p-5">
            <h3 className="font-semibold mb-3">Recent Admissions</h3>
            <div className="space-y-2">
              {recentAdmissions.map(a => (
                <div key={a.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center text-sm">
                  <div>
                    <p className="font-medium">{a.student_name}</p>
                    <p className="text-xs text-muted-foreground">{a.parent_name || "—"} · {a.contact || "—"}</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline">{a.grade}</Badge>
                    <p className="text-xs text-muted-foreground mt-1">{a.admission_date}</p>
                  </div>
                </div>
              ))}
              {recentAdmissions.length === 0 && <p className="text-sm text-muted-foreground">No admissions yet</p>}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
