import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Download, Package } from "lucide-react";
import { toast } from "sonner";
import { exportXlsx } from "@/lib/exportXlsx";
import { useAuth } from "@/contexts/AuthContext";

function StockTab({ category, canEdit }: { category: "stationary" | "sports" | "library"; canEdit: boolean }) {
  const [rows, setRows] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);

  const load = async () => {
    const { data } = await supabase.from("stock_items").select("*").eq("category", category).order("name");
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, [category]);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      category,
      name: String(fd.get("name")),
      quantity: Number(fd.get("quantity") || 0),
      unit: String(fd.get("unit") || "pcs"),
      remarks: String(fd.get("remarks") || ""),
      updated_at: new Date().toISOString(),
    };
    const { error } = editing
      ? await supabase.from("stock_items").update(payload).eq("id", editing.id)
      : await supabase.from("stock_items").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("stock_items").delete().eq("id", id); load(); };
  const exp = () => exportXlsx(
    rows.map(r => ({ Name: r.name, Quantity: r.quantity, Unit: r.unit, Remarks: r.remarks, Updated: r.updated_at?.slice(0, 10) })),
    `${category}-stock-${Date.now()}.xlsx`, category
  );

  return (
    <div className="space-y-4 mt-4">
      <div className="flex flex-wrap justify-end gap-2">
        <Button variant="outline" size="sm" onClick={exp}><Download className="w-4 h-4 mr-1" />Excel</Button>
        {canEdit && (
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
            <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-1" />Add Item</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editing ? "Edit" : "Add"} {category} item</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <Input name="name" placeholder="Item name" defaultValue={editing?.name} required />
                <div className="grid grid-cols-2 gap-2">
                  <Input name="quantity" type="number" step="0.01" placeholder="Quantity" defaultValue={editing?.quantity ?? 0} required />
                  <Input name="unit" placeholder="Unit (pcs, box…)" defaultValue={editing?.unit ?? "pcs"} />
                </div>
                <Input name="remarks" placeholder="Remarks" defaultValue={editing?.remarks} />
                <Button type="submit" className="w-full">Save</Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {rows.map(r => (
          <Card key={r.id} className="card-modern p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary grid place-items-center"><Package className="w-5 h-5" /></div>
                <div>
                  <p className="font-semibold">{r.name}</p>
                  <p className="text-xs text-muted-foreground">{r.remarks || "—"}</p>
                </div>
              </div>
              {canEdit && (
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              )}
            </div>
            <div className="mt-3 flex items-center justify-between">
              <span className="text-2xl font-bold">{r.quantity}</span>
              <Badge variant={Number(r.quantity) <= 5 ? "destructive" : "secondary"}>{r.unit}</Badge>
            </div>
          </Card>
        ))}
        {rows.length === 0 && <p className="text-sm text-muted-foreground col-span-full text-center py-8">No items</p>}
      </div>
    </div>
  );
}

export default function Stock() {
  const { primaryRole } = useAuth();
  const canEdit = primaryRole === "admin" || primaryRole === "principal";
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold">Stock</h1>
        <p className="text-muted-foreground">Stationary · Sports · Library inventory</p>
      </div>
      <Tabs defaultValue="stationary">
        <TabsList>
          <TabsTrigger value="stationary">Stationary</TabsTrigger>
          <TabsTrigger value="sports">Sports</TabsTrigger>
          <TabsTrigger value="library">Library</TabsTrigger>
        </TabsList>
        <TabsContent value="stationary"><StockTab category="stationary" canEdit={canEdit} /></TabsContent>
        <TabsContent value="sports"><StockTab category="sports" canEdit={canEdit} /></TabsContent>
        <TabsContent value="library"><StockTab category="library" canEdit={canEdit} /></TabsContent>
      </Tabs>
    </div>
  );
}
