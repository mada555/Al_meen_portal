import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Check, X } from "lucide-react";
import * as XLSX from "xlsx";
import { BrandLogo } from "@/components/BrandLogo";
import { exportXlsx } from "@/lib/exportXlsx";

export default function Admin() {
  return (
    <div className="space-y-6">
      <Card className="card-modern overflow-hidden p-0">
        <div className="bg-white w-full p-4 flex items-center justify-center border-b">
          <BrandLogo className="h-16 w-full max-w-3xl" />
        </div>
        <div className="p-5">
          <h1 className="text-2xl lg:text-3xl font-bold">Admin Panel</h1>
          <p className="text-muted-foreground">Approvals · Users · Imports · Reports</p>
        </div>
      </Card>
      <Tabs defaultValue="users">
        <TabsList className="flex-wrap h-auto bg-muted/60 p-1 rounded-xl">
          <TabsTrigger value="users">User Approvals</TabsTrigger>
          <TabsTrigger value="links">Parent Links</TabsTrigger>
          <TabsTrigger value="principal">Create Principal</TabsTrigger>
          <TabsTrigger value="chairman">Create Chairman</TabsTrigger>
          <TabsTrigger value="import">Bulk Import</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>
        <TabsContent value="users"><UsersTab /></TabsContent>
        <TabsContent value="links"><LinksTab /></TabsContent>
        <TabsContent value="principal"><CreateUserTab role="principal" /></TabsContent>
        <TabsContent value="chairman"><CreateUserTab role="chairman" /></TabsContent>
        <TabsContent value="import"><BulkImportTab /></TabsContent>
        <TabsContent value="reports"><ExportTab /></TabsContent>
      </Tabs>
    </div>
  );
}

function UsersTab() {
  const [users, setUsers] = useState<any[]>([]);
  const load = async () => {
    const { data: profs } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
    const ids = (profs ?? []).map(p => p.id);
    const { data: roles } = ids.length ? await supabase.from("user_roles").select("user_id, role").in("user_id", ids) : { data: [] as any[] };
    const map: Record<string, string[]> = {};
    (roles ?? []).forEach((r: any) => { (map[r.user_id] ??= []).push(r.role); });
    setUsers((profs ?? []).map(p => ({ ...p, roles: map[p.id] ?? [] })));
  };
  useEffect(() => { load(); }, []);

  const approve = async (u: any, role: string) => {
    await supabase.from("profiles").update({ status: "approved" }).eq("id", u.id);
    await supabase.from("user_roles").delete().eq("user_id", u.id).eq("role", "pending");
    await supabase.from("user_roles").upsert({ user_id: u.id, role: role as any }, { onConflict: "user_id,role" });
    toast.success("Approved"); load();
  };
  const reject = async (u: any) => {
    await supabase.from("profiles").update({ status: "rejected" }).eq("id", u.id);
    toast.success("Rejected"); load();
  };

  return (
    <Card className="card-modern p-5 mt-4 space-y-2">
      {users.map(u => (
        <div key={u.id} className="p-3 rounded-xl bg-muted/40 flex flex-wrap items-center gap-3 justify-between">
          <div>
            <p className="font-medium">{u.name}</p>
            <p className="text-xs text-muted-foreground">{u.identifier_type}: {u.identifier}</p>
            <div className="flex gap-1 mt-1">
              <Badge variant={u.status === "approved" ? "default" : u.status === "pending" ? "secondary" : "destructive"}>{u.status}</Badge>
              {u.roles.map((r: string) => <Badge key={r} variant="outline">{r}</Badge>)}
            </div>
          </div>
          {u.status === "pending" && (
            <div className="flex gap-2">
              <Select onValueChange={(v) => approve(u, v)}>
                <SelectTrigger className="w-36"><SelectValue placeholder="Approve as…" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="teacher">Teacher</SelectItem>
                  <SelectItem value="student">Student</SelectItem>
                  <SelectItem value="parent">Parent</SelectItem>
                  <SelectItem value="principal">Principal</SelectItem>
                  <SelectItem value="chairman">Chairman</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
              <Button size="icon" variant="ghost" onClick={() => reject(u)}><X className="w-4 h-4" /></Button>
            </div>
          )}
        </div>
      ))}
      {users.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No users</p>}
    </Card>
  );
}

function LinksTab() {
  const [links, setLinks] = useState<any[]>([]);
  const load = async () => {
    const { data } = await supabase.from("parent_child_links").select("*, profiles!parent_child_links_parent_id_fkey(name)").order("created_at", { ascending: false });
    setLinks(data ?? []);
  };
  useEffect(() => { load(); }, []);
  const decide = async (id: string, status: "approved" | "rejected") => {
    await supabase.from("parent_child_links").update({ status }).eq("id", id);
    load();
  };
  return (
    <Card className="card-modern p-5 mt-4 space-y-2">
      {links.map(l => (
        <div key={l.id} className="p-3 rounded-xl bg-muted/40 flex items-center justify-between gap-2">
          <div>
            <p className="font-medium">{l.profiles?.name || "Parent"} → Roll {l.roll_number}</p>
            <Badge variant={l.status === "approved" ? "default" : l.status === "pending" ? "secondary" : "destructive"}>{l.status}</Badge>
          </div>
          {l.status === "pending" && (
            <div className="flex gap-1">
              <Button size="icon" variant="ghost" onClick={() => decide(l.id, "approved")}><Check className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => decide(l.id, "rejected")}><X className="w-4 h-4" /></Button>
            </div>
          )}
        </div>
      ))}
      {links.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No link requests</p>}
    </Card>
  );
}

function CreateUserTab({ role }: { role: "principal" | "chairman" }) {
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const email = String(fd.get("email")); const password = String(fd.get("password"));
    const name = String(fd.get("name"));
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({
      email, password,
      options: { data: { name, identifier: email, identifier_type: "email", signup_role: role }, emailRedirectTo: window.location.origin },
    });
    if (error) { setBusy(false); return toast.error(error.message); }
    if (data.user) {
      await supabase.from("profiles").update({ status: "approved" }).eq("id", data.user.id);
      await supabase.from("user_roles").delete().eq("user_id", data.user.id).eq("role", "pending");
      await supabase.from("user_roles").upsert({ user_id: data.user.id, role: role as any }, { onConflict: "user_id,role" });
    }
    setBusy(false);
    toast.success(`${role.charAt(0).toUpperCase() + role.slice(1)} created`);
    (e.target as HTMLFormElement).reset();
  };
  return (
    <Card className="card-modern p-5 mt-4">
      <form onSubmit={submit} className="space-y-3 max-w-md">
        <div><Label>Name</Label><Input name="name" required /></div>
        <div><Label>Email</Label><Input name="email" type="email" required /></div>
        <div><Label>Password</Label><Input name="password" type="password" required minLength={6} /></div>
        <Button type="submit" disabled={busy}>Create {role}</Button>
      </form>
    </Card>
  );
}

function BulkImportTab() {
  const [rows, setRows] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const onFile = async (f: File | null) => {
    if (!f) return;
    const buf = await f.arrayBuffer();
    const wb = XLSX.read(buf);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json<any>(ws, { defval: "" });
    setRows(data);
  };
  const downloadTemplate = () => {
    const sample = [{ roll_number: "001", name: "John Doe", class: "I", section: "A" }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(sample), "students");
    XLSX.writeFile(wb, "students-template.xlsx");
  };
  const importNow = async () => {
    if (!rows.length) return toast.error("No rows to import");
    setBusy(true);
    const payload = rows.map(r => ({
      roll_number: String(r.roll_number ?? r.Roll ?? r.roll ?? "").trim(),
      name: String(r.name ?? r.Name ?? "").trim(),
      class: String(r.class ?? r.Class ?? r.grade ?? "").trim(),
      section: String(r.section ?? r.Section ?? "A").trim(),
    })).filter(r => r.roll_number && r.name && r.class);
    const { error } = await supabase.from("students").insert(payload);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(`Imported ${payload.length} students`);
    setRows([]);
  };
  return (
    <Card className="card-modern p-5 mt-4 space-y-4 max-w-2xl">
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" onClick={downloadTemplate}>Download Template</Button>
        <Input type="file" accept=".xlsx,.xls,.csv" onChange={(e) => onFile(e.target.files?.[0] ?? null)} className="max-w-xs" />
      </div>
      <p className="text-sm text-muted-foreground">Required columns: roll_number, name, class, section. Class accepts Pre-KG, LKG, UKG, I-XII.</p>
      {rows.length > 0 && (
        <>
          <p className="text-sm">Preview ({rows.length} rows)</p>
          <div className="max-h-64 overflow-auto rounded-xl bg-muted/40 p-2 text-xs">
            <pre>{JSON.stringify(rows.slice(0, 8), null, 2)}</pre>
          </div>
          <Button onClick={importNow} disabled={busy}>{busy ? "Importing…" : `Import ${rows.length} Students`}</Button>
        </>
      )}
    </Card>
  );
}

function ExportTab() {
  const [range, setRange] = useState<"today" | "weekly" | "monthly">("monthly");
  const since = () => {
    const d = new Date();
    if (range === "today") return d.toISOString().split("T")[0];
    if (range === "weekly") d.setDate(d.getDate() - 7);
    if (range === "monthly") d.setMonth(d.getMonth() - 1);
    return d.toISOString().split("T")[0];
  };
  const exportAll = async () => {
    const start = since();
    const tables = ["students","attendance","homework","marks","exams","buses","fuel_logs","bus_km_logs","fastag_recharges","bus_arrivals","eb_readings","kitchen_items","kitchen_purchases","gas_logs","admissions","enquiries","fees","stock_items","teacher_attendance","staff_attendance"];
    const wb = XLSX.utils.book_new();
    for (const t of tables) {
      let q: any = (supabase as any).from(t).select("*");
      if (["attendance","homework","marks","fuel_logs","bus_km_logs","fastag_recharges","bus_arrivals","eb_readings","kitchen_purchases","gas_logs","teacher_attendance","staff_attendance"].includes(t)) {
        q = q.gte("date", start);
      }
      const { data } = await q.limit(1000);
      const ws = XLSX.utils.json_to_sheet(data ?? []);
      XLSX.utils.book_append_sheet(wb, ws, t.slice(0, 30));
    }
    XLSX.writeFile(wb, `svm-export-${range}-${Date.now()}.xlsx`);
  };
  const exportAdmissions = async () => {
    const { data } = await supabase.from("admissions").select("*").order("admission_date", { ascending: false });
    exportXlsx((data ?? []).map(r => ({ Date: r.admission_date, Name: r.student_name, Grade: r.grade, Parent: r.parent_name, Contact: r.contact, Remarks: r.remarks })), `admissions-report-${Date.now()}.xlsx`, "Admissions");
  };
  const exportFees = async () => {
    const { data } = await supabase.from("fees").select("*").order("created_at", { ascending: false });
    exportXlsx((data ?? []).map(r => ({ Name: r.student_name, Class: r.class, "Phone.No": r.phone, "Term 1 Fee": r.term1_fee, "Total Paid": r.total_paid, "Total Balance": Number(r.term1_fee) - Number(r.total_paid) })), `fees-report-${Date.now()}.xlsx`, "Fees");
  };
  return (
    <div className="grid md:grid-cols-2 gap-4 mt-4">
      <Card className="card-modern p-5 space-y-3">
        <h3 className="font-semibold">Full Data Export</h3>
        <Label>Time range</Label>
        <Select value={range} onValueChange={(v) => setRange(v as any)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="weekly">Last 7 days</SelectItem>
            <SelectItem value="monthly">Last 30 days</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={exportAll} className="w-full">Download Combined Excel</Button>
      </Card>
      <Card className="card-modern p-5 space-y-3">
        <h3 className="font-semibold">Quick Reports</h3>
        <Button variant="outline" className="w-full" onClick={exportAdmissions}>Admissions Report</Button>
        <Button variant="outline" className="w-full" onClick={exportFees}>Fees Collection Report</Button>
      </Card>
    </div>
  );
}
