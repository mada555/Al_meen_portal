import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Pencil, Trophy, ImageIcon, Bus as BusIcon, ChevronRight, BarChart3 } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { uploadFile } from "@/lib/upload";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function Transport() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold">Transport</h1>
        <p className="text-muted-foreground">Buses · Routes · KM · Fuel · FASTag · Arrivals · Maintenance · FC</p>
      </div>
      <Tabs defaultValue="buses">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="buses">Buses</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="routes">Routes</TabsTrigger>
          <TabsTrigger value="km">KM</TabsTrigger>
          <TabsTrigger value="fuel">Fuel</TabsTrigger>
          <TabsTrigger value="fastag">FASTag</TabsTrigger>
          <TabsTrigger value="arrivals">Arrivals</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="fc">FC</TabsTrigger>
        </TabsList>
        <TabsContent value="buses"><BusesTab /></TabsContent>
        <TabsContent value="performance"><PerformanceTab /></TabsContent>
        <TabsContent value="routes"><RoutesTab /></TabsContent>
        <TabsContent value="km"><KmTab /></TabsContent>
        <TabsContent value="fuel"><FuelTab /></TabsContent>
        <TabsContent value="fastag"><FastagTab /></TabsContent>
        <TabsContent value="arrivals"><ArrivalsTab /></TabsContent>
        <TabsContent value="maintenance"><MaintenanceTab /></TabsContent>
        <TabsContent value="fc"><FcTab /></TabsContent>
      </Tabs>
    </div>
  );
}

function BusesTab() {
  const [buses, setBuses] = useState<any[]>([]); const [routes, setRoutes] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const load = async () => {
    const [{ data: b }, { data: r }] = await Promise.all([
      supabase.from("buses").select("*, routes(route_name)").order("internal_bus_number"),
      supabase.from("routes").select("*"),
    ]);
    setBuses(b ?? []); setRoutes(r ?? []);
  };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      internal_bus_number: String(fd.get("num")), number_plate: String(fd.get("plate")),
      driver: String(fd.get("driver") || ""), route_id: String(fd.get("route_id") || "") || null,
    };
    if (editing) {
      const { error } = await supabase.from("buses").update(payload).eq("id", editing.id);
      if (error) return toast.error(error.message);
    } else {
      const { data, error } = await supabase.from("buses").insert(payload).select().single();
      if (error) return toast.error(error.message);
      if (data) await supabase.from("fastag_accounts").insert({ bus_id: data.id, current_balance: 0 });
    }
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => {
    if (!confirm("Delete bus?")) return;
    await supabase.from("buses").delete().eq("id", id); load();
  };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add Bus</Button></DialogTrigger>
          <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Bus</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Input name="num" placeholder="Internal Bus Number" defaultValue={editing?.internal_bus_number} required />
              <Input name="plate" placeholder="Number Plate" defaultValue={editing?.number_plate} required />
              <Input name="driver" placeholder="Driver name" defaultValue={editing?.driver} />
              <Select name="route_id" defaultValue={editing?.route_id ?? undefined}><SelectTrigger><SelectValue placeholder="Route" /></SelectTrigger>
                <SelectContent>{routes.map(r => <SelectItem key={r.id} value={r.id}>{r.route_name}</SelectItem>)}</SelectContent>
              </Select>
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {buses.map(b => (
          <Card key={b.id} className="card-modern p-4 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between gap-2">
              <Link to={`/transport/bus/${b.id}`} className="flex items-start gap-3 flex-1 min-w-0">
                <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center shrink-0">
                  <BusIcon className="w-5 h-5 text-primary-foreground" />
                </div>
                <div className="min-w-0">
                  <p className="font-semibold truncate">Bus {b.internal_bus_number}</p>
                  <p className="text-xs text-muted-foreground truncate">{b.number_plate}</p>
                  <p className="text-xs text-muted-foreground truncate">{b.driver || "—"} · {b.routes?.route_name || "No route"}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0 ml-auto" />
              </Link>
            </div>
            <div className="flex justify-end gap-1 mt-2">
              <Button size="icon" variant="ghost" onClick={() => { setEditing(b); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => del(b.id)}><Trash2 className="w-4 h-4" /></Button>
            </div>
          </Card>
        ))}
        {buses.length === 0 && <p className="text-sm text-muted-foreground col-span-full text-center py-8">No buses yet</p>}
      </div>
    </Card>
  );
}

function RoutesTab() {
  const [list, setList] = useState<any[]>([]); const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const load = async () => { const { data } = await supabase.from("routes").select("*"); setList(data ?? []); };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = { route_name: String(fd.get("name")), toll_cost: Number(fd.get("toll") || 0) };
    const { error } = editing
      ? await supabase.from("routes").update(payload).eq("id", editing.id)
      : await supabase.from("routes").insert(payload);
    if (error) return toast.error(error.message);
    setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("routes").delete().eq("id", id); load(); };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add Route</Button></DialogTrigger>
          <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Route</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Input name="name" placeholder="Route Name" defaultValue={editing?.route_name} required />
              <Input name="toll" type="number" step="0.01" placeholder="Toll cost" defaultValue={editing?.toll_cost ?? 0} />
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="space-y-2">
        {list.map(r => (
          <div key={r.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center gap-2">
            <p className="font-medium">{r.route_name}</p>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">Toll ₹{r.toll_cost}</Badge>
              <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="w-4 h-4" /></Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function KmTab() {
  const [logs, setLogs] = useState<any[]>([]); const [buses, setBuses] = useState<any[]>([]); const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [billFile, setBillFile] = useState<File | null>(null);
  const load = async () => {
    const [{ data: l }, { data: b }] = await Promise.all([
      supabase.from("bus_km_logs").select("*, buses(internal_bus_number, route_id, routes(toll_cost))").order("date", { ascending: false }).limit(100),
      supabase.from("buses").select("id,internal_bus_number"),
    ]);
    setLogs(l ?? []); setBuses(b ?? []);
  };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const bus_id = String(fd.get("bus_id"));
    const opening = Number(fd.get("opening")); const closing = Number(fd.get("closing"));
    const total = closing; const diff = closing - opening;
    const diesel_litres = Number(fd.get("diesel") || 0);
    const mileage = diesel_litres > 0 ? Number((diff / diesel_litres).toFixed(2)) : null;
    const amount = Number(fd.get("amount") || 0);
    const date = String(fd.get("date"));
    let bill_image = editing?.bill_image ?? null;
    if (billFile) bill_image = await uploadFile(billFile, "km-bills");
    const payload: any = { bus_id, opening_km: opening, closing_km: closing, diesel_litres, mileage, amount, bill_image, date };
    const { error } = editing
      ? await supabase.from("bus_km_logs").update(payload).eq("id", editing.id)
      : await supabase.from("bus_km_logs").insert(payload);
    if (error) return toast.error(error.message);
    if (!editing && diff >= 20) {
      const { data: bus } = await supabase.from("buses").select("route_id, routes(toll_cost)").eq("id", bus_id).maybeSingle();
      const toll = Number((bus as any)?.routes?.toll_cost || 0);
      if (toll > 0) {
        const { data: acc } = await supabase.from("fastag_accounts").select("current_balance").eq("bus_id", bus_id).maybeSingle();
        const newBal = Number(acc?.current_balance || 0) - toll;
        await supabase.from("fastag_accounts").update({ current_balance: newBal }).eq("bus_id", bus_id);
      }
    }
    toast.success("Saved"); setOpen(false); setEditing(null); setBillFile(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("bus_km_logs").delete().eq("id", id); load(); };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setEditing(null); setBillFile(null); } }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Log KM</Button></DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto"><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} KM Log</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Select name="bus_id" defaultValue={editing?.bus_id}><SelectTrigger><SelectValue placeholder="Bus" /></SelectTrigger>
                <SelectContent>{buses.map(b => <SelectItem key={b.id} value={b.id}>Bus {b.internal_bus_number}</SelectItem>)}</SelectContent>
              </Select>
              <Input name="date" type="date" defaultValue={editing?.date ?? new Date().toISOString().split("T")[0]} required />
              <div className="grid grid-cols-2 gap-2">
                <Input name="opening" type="number" step="0.01" placeholder="Previous KM" defaultValue={editing?.opening_km} required />
                <Input name="closing" type="number" step="0.01" placeholder="Closing KM (Total)" defaultValue={editing?.closing_km} required />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Input name="diesel" type="number" step="0.01" placeholder="Diesel Litres" defaultValue={editing?.diesel_litres} />
                <Input name="amount" type="number" step="0.01" placeholder="Amount (₹)" defaultValue={editing?.amount} />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Bill picture</label>
                <Input type="file" accept="image/*" onChange={(e) => setBillFile(e.target.files?.[0] ?? null)} />
                {editing?.bill_image && !billFile && <a href={editing.bill_image} target="_blank" rel="noreferrer" className="text-xs text-primary underline">View existing bill</a>}
              </div>
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      {/* Mobile cards */}
      <div className="lg:hidden space-y-2">
        {logs.map(l => (
          <div key={l.id} className="p-3 rounded-xl bg-muted/40">
            <div className="flex justify-between items-start gap-2">
              <div>
                <p className="font-medium text-sm">Bus #{l.buses?.internal_bus_number} · {l.date}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {l.opening_km} → {l.closing_km} km · <span className="text-foreground font-medium">{l.distance ?? l.closing_km - l.opening_km} km</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  Diesel {l.diesel_litres ?? "—"}L · Mileage {l.mileage ?? "—"} · ₹{l.amount ?? 0}
                </p>
              </div>
              <div className="flex flex-col items-end gap-1">
                {l.bill_image && <a href={l.bill_image} target="_blank" rel="noreferrer"><ImageIcon className="w-4 h-4 text-primary" /></a>}
                <div className="flex">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(l); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(l.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {logs.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No KM logs</p>}
      </div>

      {/* Desktop table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-muted-foreground border-b">
              <th className="py-2 px-2 whitespace-nowrap">Date</th>
              <th className="px-2 whitespace-nowrap">Bus</th>
              <th className="px-2 whitespace-nowrap">Prev KM</th>
              <th className="px-2 whitespace-nowrap">Total</th>
              <th className="px-2 whitespace-nowrap">Diff</th>
              <th className="px-2 whitespace-nowrap">Diesel L</th>
              <th className="px-2 whitespace-nowrap">Mileage</th>
              <th className="px-2 whitespace-nowrap">Amount</th>
              <th className="px-2">Bill</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {logs.map(l => (
              <tr key={l.id} className="border-b last:border-0">
                <td className="py-2 px-2 whitespace-nowrap">{l.date}</td>
                <td className="px-2 whitespace-nowrap">#{l.buses?.internal_bus_number}</td>
                <td className="px-2">{l.opening_km}</td>
                <td className="px-2">{l.closing_km}</td>
                <td className="px-2"><Badge variant="secondary">{l.distance ?? l.closing_km - l.opening_km} km</Badge></td>
                <td className="px-2">{l.diesel_litres ?? "—"}</td>
                <td className="px-2">{l.mileage ?? "—"}</td>
                <td className="px-2 whitespace-nowrap">{l.amount ? `₹${l.amount}` : "—"}</td>
                <td className="px-2">{l.bill_image ? <a href={l.bill_image} target="_blank" rel="noreferrer"><ImageIcon className="w-4 h-4 text-primary" /></a> : "—"}</td>
                <td className="px-2 text-right whitespace-nowrap">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(l); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(l.id)}><Trash2 className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {logs.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No KM logs</p>}
      </div>
    </Card>
  );
}

function FuelTab() {
  const [logs, setLogs] = useState<any[]>([]); const [buses, setBuses] = useState<any[]>([]); const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [billFile, setBillFile] = useState<File | null>(null);
  const load = async () => {
    const [{ data: l }, { data: b }] = await Promise.all([
      supabase.from("fuel_logs").select("*, buses(internal_bus_number)").order("date", { ascending: false }).limit(100),
      supabase.from("buses").select("id,internal_bus_number"),
    ]);
    setLogs(l ?? []); setBuses(b ?? []);
  };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    let bill_image = editing?.bill_image ?? null;
    if (billFile) bill_image = await uploadFile(billFile, "fuel-bills");
    const payload: any = {
      bus_id: String(fd.get("bus_id")),
      date: String(fd.get("date")),
      litres: Number(fd.get("litres")),
      cost: Number(fd.get("cost")),
      odometer: Number(fd.get("odometer") || 0) || null,
      bill_image,
    };
    const { error } = editing
      ? await supabase.from("fuel_logs").update(payload).eq("id", editing.id)
      : await supabase.from("fuel_logs").insert(payload);
    if (error) return toast.error(error.message);
    setOpen(false); setEditing(null); setBillFile(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("fuel_logs").delete().eq("id", id); load(); };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setEditing(null); setBillFile(null); } }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Log Fuel</Button></DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto"><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Fuel</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Select name="bus_id" defaultValue={editing?.bus_id}><SelectTrigger><SelectValue placeholder="Bus" /></SelectTrigger>
                <SelectContent>{buses.map(b => <SelectItem key={b.id} value={b.id}>Bus {b.internal_bus_number}</SelectItem>)}</SelectContent>
              </Select>
              <Input name="date" type="date" defaultValue={editing?.date ?? new Date().toISOString().split("T")[0]} required />
              <div className="grid grid-cols-2 gap-2">
                <Input name="litres" type="number" step="0.01" placeholder="Litres" defaultValue={editing?.litres} required />
                <Input name="cost" type="number" step="0.01" placeholder="Cost (₹)" defaultValue={editing?.cost} required />
              </div>
              <Input name="odometer" type="number" step="0.01" placeholder="Odometer (KM)" defaultValue={editing?.odometer ?? ""} />
              <div>
                <label className="text-xs text-muted-foreground">Bill picture</label>
                <Input type="file" accept="image/*" onChange={(e) => setBillFile(e.target.files?.[0] ?? null)} />
                {editing?.bill_image && !billFile && <a href={editing.bill_image} target="_blank" rel="noreferrer" className="text-xs text-primary underline">View existing bill</a>}
              </div>
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="space-y-2">
        {logs.map(l => (
          <div key={l.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center gap-2">
            <div className="flex items-center gap-3 min-w-0">
              {l.bill_image && <a href={l.bill_image} target="_blank" rel="noreferrer"><img src={l.bill_image} alt="bill" className="w-12 h-12 object-cover rounded-lg" /></a>}
              <div className="min-w-0">
                <p className="font-medium truncate">Bus {l.buses?.internal_bus_number}</p>
                <p className="text-xs text-muted-foreground">{l.date} · {l.litres}L · Odo {l.odometer ?? "—"}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">₹{l.cost}</Badge>
              {l.bill_image && <a href={l.bill_image} target="_blank" rel="noreferrer"><ImageIcon className="w-4 h-4 text-primary" /></a>}
              <Button size="icon" variant="ghost" onClick={() => { setEditing(l); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => del(l.id)}><Trash2 className="w-4 h-4" /></Button>
            </div>
          </div>
        ))}
        {logs.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No fuel logs</p>}
      </div>
    </Card>
  );
}

function PerformanceTab() {
  const [data, setData] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      const [{ data: buses }, { data: km }, { data: fuel }, { data: maint }] = await Promise.all([
        supabase.from("buses").select("id,internal_bus_number"),
        supabase.from("bus_km_logs").select("bus_id,opening_km,closing_km,distance,diesel_litres,amount"),
        supabase.from("fuel_logs").select("bus_id,litres,cost"),
        supabase.from("bus_maintenance").select("bus_id,amount"),
      ]);
      const rows = (buses ?? []).map((b: any) => {
        const k = (km ?? []).filter((x: any) => x.bus_id === b.id);
        const f = (fuel ?? []).filter((x: any) => x.bus_id === b.id);
        const m = (maint ?? []).filter((x: any) => x.bus_id === b.id);
        const totalKm = k.reduce((s: number, l: any) => s + Number(l.distance ?? (Number(l.closing_km || 0) - Number(l.opening_km || 0))), 0);
        const totalL = f.reduce((s: number, l: any) => s + Number(l.litres || 0), 0) + k.reduce((s: number, l: any) => s + Number(l.diesel_litres || 0), 0);
        const fuelCost = f.reduce((s: number, l: any) => s + Number(l.cost || 0), 0) + k.reduce((s: number, l: any) => s + Number(l.amount || 0), 0);
        const maintCost = m.reduce((s: number, l: any) => s + Number(l.amount || 0), 0);
        return {
          name: `#${b.internal_bus_number}`,
          km: Math.round(totalKm),
          fuelCost: Math.round(fuelCost),
          mileage: totalL > 0 ? Number((totalKm / totalL).toFixed(2)) : 0,
          maint: Math.round(maintCost),
        };
      });
      setData(rows);
    })();
  }, []);

  const Chart = ({ title, dataKey, color }: { title: string; dataKey: string; color: string }) => (
    <Card className="card-modern p-5">
      <h3 className="font-semibold mb-3 flex items-center gap-2"><BarChart3 className="w-4 h-4" />{title}</h3>
      <div className="h-56">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
            <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }} />
            <Bar dataKey={dataKey} fill={color} radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );

  return (
    <div className="grid lg:grid-cols-2 gap-4 mt-4">
      <Chart title="KM per Bus" dataKey="km" color="hsl(var(--primary))" />
      <Chart title="Fuel Cost per Bus (₹)" dataKey="fuelCost" color="hsl(var(--warning))" />
      <Chart title="Mileage Comparison (km/L)" dataKey="mileage" color="hsl(var(--success))" />
      <Chart title="Maintenance Cost per Bus (₹)" dataKey="maint" color="hsl(var(--destructive))" />
    </div>
  );
}

function FastagTab() {
  const [accs, setAccs] = useState<any[]>([]); const [buses, setBuses] = useState<any[]>([]); const [open, setOpen] = useState(false);
  const load = async () => {
    const [{ data: a }, { data: b }] = await Promise.all([
      supabase.from("fastag_accounts").select("*, buses(internal_bus_number, number_plate)"),
      supabase.from("buses").select("id,internal_bus_number"),
    ]);
    setAccs(a ?? []); setBuses(b ?? []);
  };
  useEffect(() => { load(); }, []);
  const recharge = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const bus_id = String(fd.get("bus_id")); const amount = Number(fd.get("amount"));
    await supabase.from("fastag_recharges").insert({ bus_id, amount });
    const { data: acc } = await supabase.from("fastag_accounts").select("current_balance").eq("bus_id", bus_id).maybeSingle();
    if (acc) await supabase.from("fastag_accounts").update({ current_balance: Number(acc.current_balance) + amount }).eq("bus_id", bus_id);
    else await supabase.from("fastag_accounts").insert({ bus_id, current_balance: amount });
    toast.success("Recharged"); setOpen(false); load();
  };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-1" />Recharge</Button></DialogTrigger>
          <DialogContent><DialogHeader><DialogTitle>FASTag Recharge</DialogTitle></DialogHeader>
            <form onSubmit={recharge} className="space-y-3">
              <Select name="bus_id"><SelectTrigger><SelectValue placeholder="Bus" /></SelectTrigger>
                <SelectContent>{buses.map(b => <SelectItem key={b.id} value={b.id}>Bus {b.internal_bus_number}</SelectItem>)}</SelectContent>
              </Select>
              <Input name="amount" type="number" placeholder="Amount" required />
              <Button type="submit" className="w-full">Recharge</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="space-y-2">
        {accs.map(a => (
          <div key={a.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center">
            <div><p className="font-medium">Bus {a.buses?.internal_bus_number}</p><p className="text-xs text-muted-foreground">{a.buses?.number_plate}</p></div>
            <Badge variant={Number(a.current_balance) < 200 ? "destructive" : "default"}>₹{Number(a.current_balance).toFixed(0)}</Badge>
          </div>
        ))}
      </div>
    </Card>
  );
}

function ArrivalsTab() {
  const [list, setList] = useState<any[]>([]); const [buses, setBuses] = useState<any[]>([]); const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const load = async () => {
    const [{ data: a }, { data: b }] = await Promise.all([
      supabase.from("bus_arrivals").select("*, buses(internal_bus_number, number_plate, routes(route_name))").eq("date", date).order("arrival_time"),
      supabase.from("buses").select("id,internal_bus_number"),
    ]);
    const ranked = (a ?? []).map((x: any, i: number) => ({ ...x, rank: i + 1 }));
    setList(ranked); setBuses(b ?? []);
  };
  useEffect(() => { load(); }, [date]);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      bus_id: String(fd.get("bus_id")), date: String(fd.get("date")),
      arrival_time: String(fd.get("time")), place_route: String(fd.get("place") || ""),
      km: Number(fd.get("km") || 0),
    };
    const { error } = editing
      ? await supabase.from("bus_arrivals").update(payload).eq("id", editing.id)
      : await supabase.from("bus_arrivals").insert(payload);
    if (error) return toast.error(error.message);
    setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { await supabase.from("bus_arrivals").delete().eq("id", id); load(); };
  const medal = (r: number) => r === 1 ? "🥇" : r === 2 ? "🥈" : r === 3 ? "🥉" : `#${r}`;
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex flex-wrap justify-between items-center gap-2 mb-4">
        <div className="flex items-center gap-2"><Trophy className="w-4 h-4" /><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-auto" /></div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Log Arrival</Button></DialogTrigger>
          <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Arrival</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Input name="date" type="date" defaultValue={editing?.date ?? date} required />
              <Select name="bus_id" defaultValue={editing?.bus_id}><SelectTrigger><SelectValue placeholder="Bus" /></SelectTrigger>
                <SelectContent>{buses.map(b => <SelectItem key={b.id} value={b.id}>Bus {b.internal_bus_number}</SelectItem>)}</SelectContent>
              </Select>
              <Input name="place" placeholder="Place / Route" defaultValue={editing?.place_route} />
              <Input name="time" type="time" defaultValue={editing?.arrival_time} required />
              <Input name="km" type="number" step="0.01" placeholder="KM" defaultValue={editing?.km} />
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-muted-foreground border-b">
            <th className="py-2 px-2">Order</th><th className="px-2">Date</th><th className="px-2">Bus</th>
            <th className="px-2">Place/Route</th><th className="px-2">Time</th><th className="px-2">KM</th><th></th>
          </tr></thead>
          <tbody>
            {list.map(a => (
              <tr key={a.id} className="border-b last:border-0">
                <td className="py-2 px-2 text-lg">{medal(a.rank)}</td>
                <td className="px-2">{a.date}</td>
                <td className="px-2">#{a.buses?.internal_bus_number}</td>
                <td className="px-2">{a.place_route || a.buses?.routes?.route_name || "—"}</td>
                <td className="px-2">{a.arrival_time}</td>
                <td className="px-2">{a.km ?? "—"}</td>
                <td className="px-2 text-right whitespace-nowrap">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(a); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(a.id)}><Trash2 className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No arrivals on this date</p>}
      </div>
    </Card>
  );
}

function MaintenanceTab() {
  const [list, setList] = useState<any[]>([]); const [buses, setBuses] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [imgFile, setImgFile] = useState<File | null>(null);
  const load = async () => {
    const [{ data: m }, { data: b }] = await Promise.all([
      supabase.from("bus_maintenance").select("*, buses(internal_bus_number)").order("date", { ascending: false }).limit(200),
      supabase.from("buses").select("id,internal_bus_number"),
    ]);
    setList(m ?? []); setBuses(b ?? []);
  };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    let image_url = editing?.image_url ?? null;
    if (imgFile) image_url = await uploadFile(imgFile, "maintenance");
    const payload: any = {
      date: String(fd.get("date")),
      bus_id: String(fd.get("bus_id") || "") || null,
      vendor_name: String(fd.get("vendor")),
      item_description: String(fd.get("item")),
      bill_no: String(fd.get("bill_no") || ""),
      amount: Number(fd.get("amount") || 0),
      remarks: String(fd.get("remarks") || ""),
      image_url,
    };
    const { error } = editing
      ? await supabase.from("bus_maintenance").update(payload).eq("id", editing.id)
      : await supabase.from("bus_maintenance").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); setImgFile(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("bus_maintenance").delete().eq("id", id); load(); };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setEditing(null); setImgFile(null); } }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add Maintenance</Button></DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto"><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Maintenance</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Input name="date" type="date" defaultValue={editing?.date ?? new Date().toISOString().split("T")[0]} required />
              <Select name="bus_id" defaultValue={editing?.bus_id ?? undefined}><SelectTrigger><SelectValue placeholder="Bus (optional)" /></SelectTrigger>
                <SelectContent>{buses.map(b => <SelectItem key={b.id} value={b.id}>Bus {b.internal_bus_number}</SelectItem>)}</SelectContent>
              </Select>
              <Input name="vendor" placeholder="Vendor name" defaultValue={editing?.vendor_name} required />
              <Input name="item" placeholder="Item / Description" defaultValue={editing?.item_description} required />
              <div className="grid grid-cols-2 gap-2">
                <Input name="bill_no" placeholder="Bill No" defaultValue={editing?.bill_no} />
                <Input name="amount" type="number" step="0.01" placeholder="Amount" defaultValue={editing?.amount} />
              </div>
              <Input name="remarks" placeholder="Remarks" defaultValue={editing?.remarks} />
              <div>
                <label className="text-xs text-muted-foreground">Image proof</label>
                <Input type="file" accept="image/*" onChange={(e) => setImgFile(e.target.files?.[0] ?? null)} />
                {editing?.image_url && !imgFile && <a href={editing.image_url} target="_blank" rel="noreferrer" className="text-xs text-primary underline">View existing</a>}
              </div>
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-muted-foreground border-b">
            <th className="py-2 px-2">S.No</th><th className="px-2">Date</th><th className="px-2">Vendor</th>
            <th className="px-2">Item / Desc</th><th className="px-2">Bill No</th><th className="px-2">Amount</th>
            <th className="px-2">Remarks</th><th className="px-2">Image</th><th></th>
          </tr></thead>
          <tbody>
            {list.map(m => (
              <tr key={m.id} className="border-b last:border-0">
                <td className="py-2 px-2 font-mono text-xs">{m.serial_no}</td>
                <td className="px-2">{m.date}</td>
                <td className="px-2">{m.vendor_name}</td>
                <td className="px-2">{m.item_description}</td>
                <td className="px-2">{m.bill_no || "—"}</td>
                <td className="px-2">₹{m.amount}</td>
                <td className="px-2">{m.remarks || "—"}</td>
                <td className="px-2">{m.image_url ? <a href={m.image_url} target="_blank" rel="noreferrer"><ImageIcon className="w-4 h-4 text-primary" /></a> : "—"}</td>
                <td className="px-2 text-right whitespace-nowrap">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(m); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(m.id)}><Trash2 className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No maintenance records</p>}
      </div>
    </Card>
  );
}

function FcTab() {
  const [list, setList] = useState<any[]>([]); const [buses, setBuses] = useState<any[]>([]);
  const [open, setOpen] = useState(false); const [editing, setEditing] = useState<any>(null);
  const [imgFile, setImgFile] = useState<File | null>(null);
  const load = async () => {
    const [{ data: f }, { data: b }] = await Promise.all([
      supabase.from("fitness_certificates").select("*, buses(internal_bus_number, number_plate)").order("expiry_date"),
      supabase.from("buses").select("id,internal_bus_number"),
    ]);
    setList(f ?? []); setBuses(b ?? []);
  };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    let image_url = editing?.image_url ?? null;
    if (imgFile) image_url = await uploadFile(imgFile, "fc");
    const payload: any = {
      bus_id: String(fd.get("bus_id")),
      fc_number: String(fd.get("fc_number") || ""),
      issue_date: String(fd.get("issue") || "") || null,
      expiry_date: String(fd.get("expiry")),
      remarks: String(fd.get("remarks") || ""),
      image_url,
    };
    const { error } = editing
      ? await supabase.from("fitness_certificates").update(payload).eq("id", editing.id)
      : await supabase.from("fitness_certificates").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); setImgFile(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("fitness_certificates").delete().eq("id", id); load(); };
  const daysLeft = (d: string) => Math.ceil((new Date(d).getTime() - Date.now()) / 86400000);
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setEditing(null); setImgFile(null); } }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add FC</Button></DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto"><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Fitness Certificate</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Select name="bus_id" defaultValue={editing?.bus_id}><SelectTrigger><SelectValue placeholder="Bus" /></SelectTrigger>
                <SelectContent>{buses.map(b => <SelectItem key={b.id} value={b.id}>Bus {b.internal_bus_number}</SelectItem>)}</SelectContent>
              </Select>
              <Input name="fc_number" placeholder="FC Number" defaultValue={editing?.fc_number} />
              <div className="grid grid-cols-2 gap-2">
                <div><label className="text-xs text-muted-foreground">Issue date</label><Input name="issue" type="date" defaultValue={editing?.issue_date ?? ""} /></div>
                <div><label className="text-xs text-muted-foreground">Expiry date</label><Input name="expiry" type="date" defaultValue={editing?.expiry_date} required /></div>
              </div>
              <Input name="remarks" placeholder="Remarks" defaultValue={editing?.remarks} />
              <div>
                <label className="text-xs text-muted-foreground">FC Scan / Image</label>
                <Input type="file" accept="image/*" onChange={(e) => setImgFile(e.target.files?.[0] ?? null)} />
                {editing?.image_url && !imgFile && <a href={editing.image_url} target="_blank" rel="noreferrer" className="text-xs text-primary underline">View existing</a>}
              </div>
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="space-y-2">
        {list.map(f => {
          const dl = daysLeft(f.expiry_date);
          return (
            <div key={f.id} className="p-3 rounded-xl bg-muted/40 flex flex-wrap justify-between items-center gap-2">
              <div>
                <p className="font-medium">Bus {f.buses?.internal_bus_number} · {f.buses?.number_plate}</p>
                <p className="text-xs text-muted-foreground">FC {f.fc_number || "—"} · Expires {f.expiry_date}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={dl < 0 ? "destructive" : dl < 30 ? "secondary" : "default"}>
                  {dl < 0 ? `Expired ${-dl}d ago` : `${dl} days left`}
                </Badge>
                {f.image_url && <a href={f.image_url} target="_blank" rel="noreferrer"><ImageIcon className="w-4 h-4 text-primary" /></a>}
                <Button size="icon" variant="ghost" onClick={() => { setEditing(f); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => del(f.id)}><Trash2 className="w-4 h-4" /></Button>
              </div>
            </div>
          );
        })}
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No FC records</p>}
      </div>
    </Card>
  );
}
