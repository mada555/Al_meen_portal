import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CLASSES, SECTIONS } from "@/lib/constants";
import { toast } from "sonner";
import { Plus, Trash2, Check, Pencil } from "lucide-react";
import { format } from "date-fns";

export default function Academic() {
  const { primaryRole } = useAuth();
  const isStaff = primaryRole === "admin" || primaryRole === "teacher" || primaryRole === "principal";
  const showStudents = isStaff; // hide students list from students/parents

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold">Academic</h1>
        <p className="text-muted-foreground">Attendance · Homework · Marks · Exams</p>
      </div>
      <Tabs defaultValue={showStudents ? "students" : "homework"}>
        <TabsList className="flex-wrap h-auto">
          {showStudents && <TabsTrigger value="students">Students</TabsTrigger>}
          {isStaff && <TabsTrigger value="attendance">Attendance</TabsTrigger>}
          <TabsTrigger value="homework">Homework</TabsTrigger>
          <TabsTrigger value="marks">Marks</TabsTrigger>
          <TabsTrigger value="exams">Exams</TabsTrigger>
        </TabsList>
        {showStudents && <TabsContent value="students"><StudentsTab canEdit={isStaff} /></TabsContent>}
        {isStaff && <TabsContent value="attendance"><AttendanceTab canEdit={isStaff} /></TabsContent>}
        <TabsContent value="homework"><HomeworkTab canEdit={isStaff} /></TabsContent>
        <TabsContent value="marks"><MarksTab canEdit={isStaff} /></TabsContent>
        <TabsContent value="exams"><ExamsTab canEdit={isStaff} /></TabsContent>
      </Tabs>
    </div>
  );
}

function StudentsTab({ canEdit }: { canEdit: boolean }) {
  const [list, setList] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const load = async () => {
    const { data } = await supabase.from("students").select("*").order("class").order("section").order("roll_number");
    setList(data ?? []);
  };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      roll_number: String(fd.get("roll")), name: String(fd.get("name")),
      class: String(fd.get("class")), section: String(fd.get("section")),
    };
    const { error } = editing
      ? await supabase.from("students").update(payload).eq("id", editing.id)
      : await supabase.from("students").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => {
    if (!confirm("Delete this student?")) return;
    const { error } = await supabase.from("students").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted"); load();
  };
  return (
    <Card className="card-modern p-5 mt-4">
      {canEdit && (
        <div className="flex justify-end mb-4">
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
            <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add Student</Button></DialogTrigger>
            <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Student</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <Input name="name" placeholder="Name" defaultValue={editing?.name} required />
                <Input name="roll" placeholder="Roll Number" defaultValue={editing?.roll_number} required />
                <div className="grid grid-cols-2 gap-2">
                  <Select name="class" defaultValue={editing?.class ?? "I"}><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{CLASSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                  <Select name="section" defaultValue={editing?.section ?? "A"}><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{SECTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full">Save</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      )}
      <div className="space-y-2">
        {list.map(s => (
          <div key={s.id} className="flex items-center justify-between p-3 rounded-xl bg-muted/40">
            <div>
              <p className="font-medium">{s.name}</p>
              <p className="text-xs text-muted-foreground">Roll {s.roll_number} · {s.class}-{s.section}</p>
            </div>
            {canEdit && <div className="flex gap-1">
              <Button size="icon" variant="ghost" onClick={() => { setEditing(s); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => del(s.id)}><Trash2 className="w-4 h-4" /></Button>
            </div>}
          </div>
        ))}
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No students yet</p>}
      </div>
    </Card>
  );
}

function AttendanceTab({ canEdit }: { canEdit: boolean }) {
  const [cls, setCls] = useState("I"); const [sec, setSec] = useState("A");
  const [students, setStudents] = useState<any[]>([]);
  const [marks, setMarks] = useState<Record<string, boolean>>({});
  const today = format(new Date(), "yyyy-MM-dd");
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("students").select("*").eq("class", cls).eq("section", sec).order("roll_number");
      setStudents(data ?? []);
      const ids = (data ?? []).map(d => d.id);
      if (ids.length) {
        const { data: att } = await supabase.from("attendance").select("*").eq("date", today).in("student_id", ids);
        const m: Record<string, boolean> = {};
        (att ?? []).forEach((a: any) => m[a.student_id] = a.present);
        setMarks(m);
      } else setMarks({});
    })();
  }, [cls, sec]);
  const toggle = async (sid: string) => {
    if (!canEdit) return;
    const next = !marks[sid];
    setMarks(p => ({ ...p, [sid]: next }));
    const { error } = await supabase.from("attendance").upsert({ student_id: sid, date: today, present: next }, { onConflict: "student_id,date" });
    if (error) toast.error(error.message);
  };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex gap-2 mb-4">
        <Select value={cls} onValueChange={setCls}><SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
          <SelectContent>{CLASSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={sec} onValueChange={setSec}><SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
          <SelectContent>{SECTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
        </Select>
        <Badge variant="secondary" className="ml-auto self-center">{today}</Badge>
      </div>
      <div className="space-y-2">
        {students.map(s => (
          <div key={s.id} onClick={() => toggle(s.id)}
            className={`flex items-center justify-between p-3 rounded-xl cursor-pointer transition ${marks[s.id] ? "bg-success/10 border border-success/30" : "bg-muted/40"}`}>
            <div>
              <p className="font-medium">{s.name}</p>
              <p className="text-xs text-muted-foreground">Roll {s.roll_number}</p>
            </div>
            {marks[s.id] ? <Check className="w-5 h-5 text-success" /> : <span className="text-xs text-muted-foreground">Tap to mark present</span>}
          </div>
        ))}
        {students.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No students in this section</p>}
      </div>
    </Card>
  );
}

function HomeworkTab({ canEdit }: { canEdit: boolean }) {
  const { user } = useAuth();
  const [list, setList] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [completions, setCompletions] = useState<Record<string, any>>({});
  const [studentId, setStudentId] = useState<string | null>(null);

  const load = async () => {
    const { data } = await supabase.from("homework").select("*").order("created_at", { ascending: false });
    setList(data ?? []);
    if (user) {
      // figure out student id linked to this user
      const { data: stu } = await supabase.from("students").select("id").eq("user_id", user.id).maybeSingle();
      const sid = stu?.id ?? null;
      setStudentId(sid);
      if (sid) {
        const { data: comps } = await supabase.from("homework_completion").select("*").eq("student_id", sid);
        const map: Record<string, any> = {};
        (comps ?? []).forEach((c: any) => { map[c.homework_id] = c; });
        setCompletions(map);
      }
    }
  };
  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      class: String(fd.get("class")), section: String(fd.get("section")),
      subject: String(fd.get("subject")), title: String(fd.get("title")),
      description: String(fd.get("description") || ""), due_date: String(fd.get("due") || ""),
    };
    const { error } = editing
      ? await supabase.from("homework").update(payload).eq("id", editing.id)
      : await supabase.from("homework").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(editing ? "Updated" : "Posted"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => {
    if (!confirm("Delete?")) return;
    await supabase.from("homework").delete().eq("id", id); load();
  };
  const markComplete = async (hwId: string, file: File | null) => {
    if (!studentId) return toast.error("No student profile linked");
    let proof_url: string | null = null;
    if (file) {
      const { uploadFile } = await import("@/lib/upload");
      proof_url = await uploadFile(file, "homework");
      if (!proof_url) return toast.error("Upload failed");
    }
    await supabase.from("homework_completion").delete().eq("student_id", studentId).eq("homework_id", hwId);
    const { error } = await supabase.from("homework_completion")
      .insert({ student_id: studentId, homework_id: hwId, completed: true, proof_url });
    if (error) return toast.error(error.message);
    toast.success("Marked complete"); load();
  };

  return (
    <Card className="card-modern p-5 mt-4">
      {canEdit && (
        <div className="flex justify-end mb-4">
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
            <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add Homework</Button></DialogTrigger>
            <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Homework</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <Input name="title" placeholder="Title" defaultValue={editing?.title} required />
                <Input name="subject" placeholder="Subject" defaultValue={editing?.subject} required />
                <div className="grid grid-cols-2 gap-2">
                  <Select name="class" defaultValue={editing?.class ?? "I"}><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{CLASSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                  <Select name="section" defaultValue={editing?.section ?? "A"}><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{SECTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <Input name="due" type="date" defaultValue={editing?.due_date} required />
                <Input name="description" placeholder="Description" defaultValue={editing?.description} />
                <Button type="submit" className="w-full">{editing ? "Update" : "Post"}</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      )}
      <div className="space-y-2">
        {list.map(h => {
          const comp = completions[h.id];
          return (
            <div key={h.id} className="p-4 rounded-xl bg-muted/40">
              <div className="flex justify-between items-start gap-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-medium">{h.title}</p>
                    <Badge variant="outline">{h.class}-{h.section}</Badge>
                    {comp?.completed && <Badge className="bg-success/20 text-success border-success/30">✓ Done</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground">{h.subject} · Due {h.due_date}</p>
                  {h.description && <p className="text-sm mt-1">{h.description}</p>}
                  {comp?.proof_url && (
                    <a href={comp.proof_url} target="_blank" rel="noreferrer" className="inline-block mt-2">
                      <img src={comp.proof_url} alt="proof" className="h-20 rounded-lg border" />
                    </a>
                  )}
                </div>
                <div className="flex flex-col gap-1">
                  {canEdit && <>
                    <Button size="icon" variant="ghost" onClick={() => { setEditing(h); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => del(h.id)}><Trash2 className="w-4 h-4" /></Button>
                  </>}
                </div>
              </div>
              {!canEdit && studentId && (
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <label className="text-xs text-muted-foreground">{comp?.completed ? "Re-upload proof:" : "Upload proof image to mark complete:"}</label>
                  <Input type="file" accept="image/*" className="max-w-xs"
                    onChange={(e) => markComplete(h.id, e.target.files?.[0] ?? null)} />
                </div>
              )}
            </div>
          );
        })}
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No homework yet</p>}
      </div>
    </Card>
  );
}

function MarksTab({ canEdit }: { canEdit: boolean }) {
  const { user } = useAuth();
  const [list, setList] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const load = async () => {
    let q = supabase.from("marks").select("*, students(name, roll_number, class, section, user_id)").order("recorded_at", { ascending: false }).limit(500);
    const { data: m } = await q;
    let filtered = m ?? [];
    if (!canEdit && user) filtered = filtered.filter((row: any) => row.students?.user_id === user.id);
    const { data: s } = await supabase.from("students").select("id,name,roll_number").order("roll_number");
    setList(filtered); setStudents(s ?? []);
  };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      student_id: String(fd.get("student_id")), subject: String(fd.get("subject")),
      exam: String(fd.get("exam")), score: Number(fd.get("score")), max_score: Number(fd.get("max_score") || 100),
    };
    const { error } = editing
      ? await supabase.from("marks").update(payload).eq("id", editing.id)
      : await supabase.from("marks").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("marks").delete().eq("id", id); load(); };
  return (
    <Card className="card-modern p-5 mt-4">
      {canEdit && (
        <div className="flex justify-end mb-4">
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
            <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add Marks</Button></DialogTrigger>
            <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "Add"} Marks</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <Select name="student_id" defaultValue={editing?.student_id}><SelectTrigger><SelectValue placeholder="Student" /></SelectTrigger>
                  <SelectContent>{students.map(s => <SelectItem key={s.id} value={s.id}>{s.name} ({s.roll_number})</SelectItem>)}</SelectContent>
                </Select>
                <Input name="subject" placeholder="Subject" defaultValue={editing?.subject} required />
                <Input name="exam" placeholder="Exam name" defaultValue={editing?.exam} required />
                <div className="grid grid-cols-2 gap-2">
                  <Input name="score" type="number" placeholder="Score" defaultValue={editing?.score} required />
                  <Input name="max_score" type="number" defaultValue={editing?.max_score ?? 100} />
                </div>
                <Button type="submit" className="w-full">Save</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      )}
      <div className="space-y-2">
        {list.map(m => {
          const pct = Math.round((Number(m.score) / Number(m.max_score)) * 100);
          return (
            <div key={m.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center gap-2">
              <div>
                <p className="font-medium">{m.students?.name}</p>
                <p className="text-xs text-muted-foreground">{m.subject} · {m.exam}</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-right">
                  <p className="font-semibold">{m.score}/{m.max_score}</p>
                  <Badge variant={pct < 40 ? "destructive" : pct < 75 ? "secondary" : "default"}>{pct}%</Badge>
                </div>
                {canEdit && <>
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(m); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(m.id)}><Trash2 className="w-4 h-4" /></Button>
                </>}
              </div>
            </div>
          );
        })}
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No marks recorded</p>}
      </div>
    </Card>
  );
}

function ExamsTab({ canEdit }: { canEdit: boolean }) {
  const [list, setList] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const load = async () => {
    const { data } = await supabase.from("exams").select("*").order("exam_date");
    setList(data ?? []);
  };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      class: String(fd.get("class")), section: String(fd.get("section") || ""),
      subject: String(fd.get("subject")), exam_date: String(fd.get("date")),
      start_time: String(fd.get("time") || "") || null, notes: String(fd.get("notes") || ""),
    };
    const { error } = editing
      ? await supabase.from("exams").update(payload).eq("id", editing.id)
      : await supabase.from("exams").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("exams").delete().eq("id", id); load(); };
  return (
    <Card className="card-modern p-5 mt-4">
      {canEdit && (
        <div className="flex justify-end mb-4">
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
            <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Schedule Exam</Button></DialogTrigger>
            <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Exam</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <Input name="subject" placeholder="Subject" defaultValue={editing?.subject} required />
                <div className="grid grid-cols-2 gap-2">
                  <Select name="class" defaultValue={editing?.class ?? "I"}><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{CLASSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                  <Select name="section" defaultValue={editing?.section ?? "A"}><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{SECTIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <Input name="date" type="date" defaultValue={editing?.exam_date} required />
                <Input name="time" type="time" defaultValue={editing?.start_time ?? ""} />
                <Input name="notes" placeholder="Notes" defaultValue={editing?.notes} />
                <Button type="submit" className="w-full">Save</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      )}
      <div className="space-y-2">
        {list.map(ex => (
          <div key={ex.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center gap-2">
            <div>
              <p className="font-medium">{ex.subject}</p>
              <p className="text-xs text-muted-foreground">{ex.class}{ex.section ? `-${ex.section}` : ""} · {ex.exam_date} {ex.start_time ?? ""}</p>
            </div>
            {canEdit && <div className="flex gap-1">
              <Button size="icon" variant="ghost" onClick={() => { setEditing(ex); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => del(ex.id)}><Trash2 className="w-4 h-4" /></Button>
            </div>}
          </div>
        ))}
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No exams scheduled</p>}
      </div>
    </Card>
  );
}
