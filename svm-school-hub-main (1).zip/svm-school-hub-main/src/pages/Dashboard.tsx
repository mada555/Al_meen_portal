import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { StatCard } from "@/components/StatCard";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, BookOpen, Bus, Zap, ChefHat, AlertTriangle, TrendingUp, Fuel } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { format, subDays } from "date-fns";
import { BrandLogo } from "@/components/BrandLogo";

export default function Dashboard() {
  const { profile, primaryRole } = useAuth();
  const [stats, setStats] = useState<any>({});
  const [trend, setTrend] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<{ type: string; message: string }[]>([]);

  useEffect(() => {
    (async () => {
      const today = format(new Date(), "yyyy-MM-dd");
      const [students, attendance, hwPending, buses, fuel, eb, kitchen, fastags, exams] = await Promise.all([
        supabase.from("students").select("id", { count: "exact", head: true }),
        supabase.from("attendance").select("present", { count: "exact" }).eq("date", today),
        supabase.from("homework").select("id", { count: "exact", head: true }).gte("due_date", today),
        supabase.from("buses").select("id", { count: "exact", head: true }),
        supabase.from("fuel_logs").select("cost,litres").gte("date", format(subDays(new Date(), 7), "yyyy-MM-dd")),
        supabase.from("eb_readings").select("units").gte("date", format(subDays(new Date(), 30), "yyyy-MM-dd")),
        supabase.from("kitchen_items").select("stock,name"),
        supabase.from("fastag_accounts").select("current_balance,bus_id"),
        supabase.from("exams").select("id,exam_date,subject").gte("exam_date", today).order("exam_date").limit(3),
      ]);
      const present = (attendance.data ?? []).filter((a: any) => a.present).length;
      const total = attendance.count ?? 0;
      const pct = total ? Math.round((present / total) * 100) : 0;
      const fuelCost = (fuel.data ?? []).reduce((s: number, f: any) => s + Number(f.cost || 0), 0);
      const ebUnits = (eb.data ?? []).reduce((s: number, r: any) => s + Number(r.units || 0), 0);
      const lowStock = (kitchen.data ?? []).filter((k: any) => Number(k.stock) < 5);
      const lowFastag = (fastags.data ?? []).filter((f: any) => Number(f.current_balance) < 200);

      setStats({
        students: students.count ?? 0,
        attendancePct: pct,
        hwPending: hwPending.count ?? 0,
        buses: buses.count ?? 0,
        fuelCost,
        ebUnits,
        kitchenItems: kitchen.data?.length ?? 0,
        upcomingExams: exams.data ?? [],
      });

      const a: { type: string; message: string }[] = [];
      if (pct && pct < 75) a.push({ type: "warning", message: `Today's attendance is low (${pct}%)` });
      lowFastag.forEach(() => a.push({ type: "warning", message: `FASTag balance below ₹200` }));
      lowStock.forEach((k: any) => a.push({ type: "warning", message: `Low stock: ${k.name}` }));
      (exams.data ?? []).slice(0, 2).forEach((e: any) =>
        a.push({ type: "info", message: `Upcoming exam: ${e.subject} on ${e.exam_date}` }));
      setAlerts(a);

      // 7-day attendance trend
      const days = Array.from({ length: 7 }, (_, i) => format(subDays(new Date(), 6 - i), "yyyy-MM-dd"));
      const { data: weekAtt } = await supabase.from("attendance")
        .select("date,present").in("date", days);
      const map: Record<string, { present: number; total: number }> = {};
      days.forEach(d => map[d] = { present: 0, total: 0 });
      (weekAtt ?? []).forEach((r: any) => {
        map[r.date].total++; if (r.present) map[r.date].present++;
      });
      setTrend(days.map(d => ({
        day: format(new Date(d), "EEE"),
        attendance: map[d].total ? Math.round(map[d].present / map[d].total * 100) : 0,
      })));
    })();
  }, []);

  const isStaff = primaryRole === "admin" || primaryRole === "principal";
  const showTransport = isStaff;

  return (
    <div className="space-y-6">
      <div className="w-full rounded-2xl bg-gradient-to-r from-primary/10 via-card to-card border overflow-hidden">
        <div className="w-full bg-white py-6 flex items-center justify-center">
          <BrandLogo className="h-24 w-auto max-w-full" />
        </div>
        <div className="p-4 lg:p-5">
          <h1 className="text-xl lg:text-2xl font-bold">Hello, {profile?.name?.split(" ")[0]} 👋</h1>
          <p className="text-muted-foreground text-sm capitalize">{primaryRole} dashboard · {format(new Date(), "EEEE, MMM d")}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <StatCard label="Students" value={stats.students ?? "-"} icon={Users} variant="primary" />
        <StatCard label="Attendance" value={`${stats.attendancePct ?? 0}%`} icon={TrendingUp} variant="success" />
        <StatCard label="Homework Active" value={stats.hwPending ?? 0} icon={BookOpen} />
        {showTransport && <StatCard label="Buses" value={stats.buses ?? 0} icon={Bus} />}
        {showTransport && <StatCard label="Fuel (7d)" value={`₹${(stats.fuelCost ?? 0).toLocaleString()}`} icon={Fuel} variant="warning" />}
        {showTransport && <StatCard label="EB Units (30d)" value={(stats.ebUnits ?? 0).toFixed(0)} icon={Zap} />}
        {showTransport && <StatCard label="Kitchen Items" value={stats.kitchenItems ?? 0} icon={ChefHat} />}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="card-modern p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Attendance Trend</h3>
            <Badge variant="secondary">7 days</Badge>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trend}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }} />
                <Area type="monotone" dataKey="attendance" stroke="hsl(var(--primary))" fill="url(#g1)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="card-modern p-5">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-warning" />
            <h3 className="font-semibold">Alerts</h3>
          </div>
          <div className="space-y-2 max-h-56 overflow-y-auto">
            {alerts.length === 0 && <p className="text-sm text-muted-foreground">No active alerts</p>}
            {alerts.map((a, i) => (
              <div key={i} className="text-sm p-3 rounded-xl bg-muted/50 border-l-2 border-warning">
                {a.message}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
