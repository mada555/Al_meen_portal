import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Download, Upload, FileText } from "lucide-react";
import { toast } from "sonner";
import { CLASSES } from "@/lib/constants";
import { exportXlsx } from "@/lib/exportXlsx";
import { readXlsx, downloadTemplate } from "@/lib/importXlsx";
import { useAuth } from "@/contexts/AuthContext";

export default function Enquiries() {
  const { primaryRole } = useAuth();
  const canEdit = primaryRole === "admin" || primaryRole === "principal";
  const [rows, setRows] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);

  const load = async () => {
    const { data } = await supabase.from("enquiries").select("*").order("created_at", { ascending: false });
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      student_name: String(fd.get("student_name")),
      standard: String(fd.get("standard")),
      contact: String(fd.get("contact") || ""),
      remarks: String(fd.get("remarks") || ""),
      status: String(fd.get("status") || "new"),
    };
    const { error } = editing
      ? await supabase.from("enquiries").update(payload).eq("id", editing.id)
      : await supabase.from("enquiries").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("enquiries").delete().eq("id", id); load(); };

  const exp = () => exportXlsx(
    rows.map(r => ({ student_name: r.student_name, standard: r.standard, contact: r.contact, status: r.status, remarks: r.remarks, Date: r.created_at?.slice(0, 10) })),
    `enquiries-${Date.now()}.xlsx`, "Enquiries"
  );

  const onImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      const data = await readXlsx(file);
      const payload = data.map((r: any) => ({
        student_name: String(r.student_name || r.Name || "").trim(),
        standard: String(r.standard || r.Standard || r.class || "").trim(),
        contact: String(r.contact || r.Contact || ""),
        remarks: String(r.remarks || r.Remarks || ""),
        status: String(r.status || "new").toLowerCase(),
      })).filter(p => p.student_name && p.standard);
      if (!payload.length) return toast.error("No valid rows");
      const { error } = await supabase.from("enquiries").insert(payload);
      if (error) return toast.error(error.message);
      toast.success(`Imported ${payload.length}`); load();
    } catch (err: any) { toast.error(err.message || "Import failed"); }
    e.target.value = "";
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-end gap-3">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Student Enquiries</h1>
          <p className="text-muted-foreground">Walk-in admission interest tracker</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="ghost" size="sm" onClick={() => downloadTemplate("enquiries-template.xlsx", ["student_name","standard","contact","status","remarks"])}><FileText className="w-4 h-4 mr-1" />Template</Button>
          {canEdit && <label className="cursor-pointer"><input type="file" accept=".xlsx,.csv" hidden onChange={onImport} /><Button asChild variant="outline" size="sm"><span><Upload className="w-4 h-4 mr-1" />Import</span></Button></label>}
          <Button variant="outline" size="sm" onClick={exp}><Download className="w-4 h-4 mr-1" />Excel</Button>
          {canEdit && (
            <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
              <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-1" />New Enquiry</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Enquiry</DialogTitle></DialogHeader>
                <form onSubmit={submit} className="space-y-3">
                  <Input name="student_name" placeholder="Student name" defaultValue={editing?.student_name} required />
                  <Select name="standard" defaultValue={editing?.standard}>
                    <SelectTrigger><SelectValue placeholder="Standard" /></SelectTrigger>
                    <SelectContent>{CLASSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                  <Input name="contact" placeholder="Contact number" defaultValue={editing?.contact} />
                  <Select name="status" defaultValue={editing?.status ?? "new"}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="contacted">Contacted</SelectItem>
                      <SelectItem value="visited">Visited</SelectItem>
                      <SelectItem value="admitted">Admitted</SelectItem>
                      <SelectItem value="lost">Lost</SelectItem>
                    </SelectContent>
                  </Select>
                  <Textarea name="remarks" placeholder="Remarks" defaultValue={editing?.remarks} />
                  <Button type="submit" className="w-full">Save</Button>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <Card className="card-modern p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase">
              <tr>
                <th className="text-left p-3">Name</th>
                <th className="text-left p-3">Standard</th>
                <th className="text-left p-3">Contact</th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Remarks</th>
                <th className="text-left p-3">Date</th>
                {canEdit && <th className="p-3"></th>}
              </tr>
            </thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.id} className="border-t hover:bg-muted/30">
                  <td className="p-3 font-medium">{r.student_name}</td>
                  <td className="p-3">{r.standard}</td>
                  <td className="p-3">{r.contact || "—"}</td>
                  <td className="p-3"><Badge variant="secondary" className="capitalize">{r.status}</Badge></td>
                  <td className="p-3 text-muted-foreground max-w-xs truncate">{r.remarks || "—"}</td>
                  <td className="p-3 text-xs">{r.created_at?.slice(0, 10)}</td>
                  {canEdit && (
                    <td className="p-3 flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="w-4 h-4" /></Button>
                    </td>
                  )}
                </tr>
              ))}
              {rows.length === 0 && <tr><td colSpan={7} className="text-center p-8 text-muted-foreground">No enquiries</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
