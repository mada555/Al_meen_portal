import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, Download, Upload, FileText } from "lucide-react";
import { toast } from "sonner";
import { CLASSES } from "@/lib/constants";
import { exportXlsx } from "@/lib/exportXlsx";
import { readXlsx, downloadTemplate } from "@/lib/importXlsx";
import { useAuth } from "@/contexts/AuthContext";
import { StatCard } from "@/components/StatCard";
import { IndianRupee, Wallet, AlertCircle } from "lucide-react";

export default function Fees() {
  const { primaryRole } = useAuth();
  const canEdit = primaryRole === "admin" || primaryRole === "principal";
  const [rows, setRows] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [search, setSearch] = useState("");

  const load = async () => {
    const { data } = await supabase.from("fees").select("*").order("created_at", { ascending: false });
    setRows(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      student_name: String(fd.get("student_name")),
      class: String(fd.get("class")),
      phone: String(fd.get("phone") || ""),
      term1_fee: Number(fd.get("term1_fee") || 0),
      total_paid: Number(fd.get("total_paid") || 0),
      remarks: String(fd.get("remarks") || ""),
    };
    const { error } = editing
      ? await supabase.from("fees").update(payload).eq("id", editing.id)
      : await supabase.from("fees").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("fees").delete().eq("id", id); load(); };

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return rows.filter(r => !q || r.student_name?.toLowerCase().includes(q) || r.phone?.includes(q) || r.class?.toLowerCase().includes(q));
  }, [rows, search]);

  const totals = useMemo(() => filtered.reduce((acc, r) => {
    const bal = Number(r.term1_fee) - Number(r.total_paid);
    acc.fee += Number(r.term1_fee); acc.paid += Number(r.total_paid); acc.bal += bal; return acc;
  }, { fee: 0, paid: 0, bal: 0 }), [filtered]);

  const exp = () => exportXlsx(
    filtered.map(r => ({ student_name: r.student_name, class: r.class, phone: r.phone, term1_fee: r.term1_fee, total_paid: r.total_paid, total_balance: Number(r.term1_fee) - Number(r.total_paid) })),
    `fees-collection-${Date.now()}.xlsx`, "Fees"
  );

  const onImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      const data = await readXlsx(file);
      const payload = data.map((r: any) => ({
        student_name: String(r.student_name || r.Name || "").trim(),
        class: String(r.class || r.Class || "").trim(),
        phone: String(r.phone || r.Phone || ""),
        term1_fee: Number(r.term1_fee || r["Term 1 Fee"] || 0),
        total_paid: Number(r.total_paid || r["Total Paid"] || 0),
        remarks: String(r.remarks || ""),
      })).filter(p => p.student_name && p.class);
      if (!payload.length) return toast.error("No valid rows");
      const { error } = await supabase.from("fees").insert(payload);
      if (error) return toast.error(error.message);
      toast.success(`Imported ${payload.length}`); load();
    } catch (err: any) { toast.error(err.message || "Import failed"); }
    e.target.value = "";
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-end gap-3">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Fees Collection</h1>
          <p className="text-muted-foreground">Term-wise fee tracking</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="ghost" size="sm" onClick={() => downloadTemplate("fees-template.xlsx", ["student_name","class","phone","term1_fee","total_paid","remarks"])}><FileText className="w-4 h-4 mr-1" />Template</Button>
          {canEdit && <label className="cursor-pointer"><input type="file" accept=".xlsx,.csv" hidden onChange={onImport} /><Button asChild variant="outline" size="sm"><span><Upload className="w-4 h-4 mr-1" />Import</span></Button></label>}
          <Button variant="outline" size="sm" onClick={exp}><Download className="w-4 h-4 mr-1" />Excel</Button>
          {canEdit && (
            <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
              <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-1" />Add Record</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>{editing ? "Edit" : "Add"} Fee Record</DialogTitle></DialogHeader>
                <form onSubmit={submit} className="space-y-3">
                  <Input name="student_name" placeholder="Student name" defaultValue={editing?.student_name} required />
                  <Select name="class" defaultValue={editing?.class}>
                    <SelectTrigger><SelectValue placeholder="Class" /></SelectTrigger>
                    <SelectContent>{CLASSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                  <Input name="phone" placeholder="Phone number" defaultValue={editing?.phone} />
                  <div className="grid grid-cols-2 gap-2">
                    <Input name="term1_fee" type="number" step="0.01" placeholder="Term 1 fee" defaultValue={editing?.term1_fee} required />
                    <Input name="total_paid" type="number" step="0.01" placeholder="Total paid" defaultValue={editing?.total_paid} required />
                  </div>
                  <Input name="remarks" placeholder="Remarks" defaultValue={editing?.remarks} />
                  <Button type="submit" className="w-full">Save</Button>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <StatCard label="Total Fee" value={`₹${totals.fee.toLocaleString()}`} icon={IndianRupee} />
        <StatCard label="Collected" value={`₹${totals.paid.toLocaleString()}`} icon={Wallet} variant="success" />
        <StatCard label="Balance" value={`₹${totals.bal.toLocaleString()}`} icon={AlertCircle} variant="warning" />
      </div>

      <Input placeholder="Search by name, phone, class…" value={search} onChange={e => setSearch(e.target.value)} className="max-w-sm" />

      <Card className="card-modern p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-primary text-primary-foreground text-xs uppercase">
              <tr>
                <th className="text-left p-3">Name</th>
                <th className="text-left p-3">Class</th>
                <th className="text-left p-3">Phone.No</th>
                <th className="text-right p-3">Term 1 Fee</th>
                <th className="text-right p-3">Total Paid</th>
                <th className="text-right p-3">Total Balance</th>
                {canEdit && <th className="p-3"></th>}
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => {
                const bal = Number(r.term1_fee) - Number(r.total_paid);
                return (
                  <tr key={r.id} className="border-t hover:bg-muted/30">
                    <td className="p-3 font-medium">{r.student_name}</td>
                    <td className="p-3">{r.class}</td>
                    <td className="p-3">{r.phone || "—"}</td>
                    <td className="p-3 text-right">₹{Number(r.term1_fee).toLocaleString()}</td>
                    <td className="p-3 text-right text-green-600">₹{Number(r.total_paid).toLocaleString()}</td>
                    <td className={`p-3 text-right font-semibold ${bal > 0 ? "text-destructive" : "text-muted-foreground"}`}>₹{bal.toLocaleString()}</td>
                    {canEdit && (
                      <td className="p-3 flex gap-1 justify-end">
                        <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                        <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="w-4 h-4" /></Button>
                      </td>
                    )}
                  </tr>
                );
              })}
              {filtered.length === 0 && <tr><td colSpan={7} className="text-center p-8 text-muted-foreground">No records</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
