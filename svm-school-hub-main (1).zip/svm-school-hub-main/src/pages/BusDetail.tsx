import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ImageIcon, Fuel, Wrench, CreditCard, Gauge } from "lucide-react";
import { StatCard } from "@/components/StatCard";

export default function BusDetail() {
  const { id } = useParams();
  const [bus, setBus] = useState<any>(null);
  const [km, setKm] = useState<any[]>([]);
  const [fuel, setFuel] = useState<any[]>([]);
  const [maint, setMaint] = useState<any[]>([]);
  const [fastag, setFastag] = useState<any>(null);
  const [recharges, setRecharges] = useState<any[]>([]);
  const [fc, setFc] = useState<any[]>([]);

  useEffect(() => {
    if (!id) return;
    (async () => {
      const [b, k, f, m, ft, rc, fcs] = await Promise.all([
        supabase.from("buses").select("*, routes(route_name, toll_cost)").eq("id", id).maybeSingle(),
        supabase.from("bus_km_logs").select("*").eq("bus_id", id).order("date", { ascending: false }),
        supabase.from("fuel_logs").select("*").eq("bus_id", id).order("date", { ascending: false }),
        supabase.from("bus_maintenance").select("*").eq("bus_id", id).order("date", { ascending: false }),
        supabase.from("fastag_accounts").select("*").eq("bus_id", id).maybeSingle(),
        supabase.from("fastag_recharges").select("*").eq("bus_id", id).order("date", { ascending: false }),
        supabase.from("fitness_certificates").select("*").eq("bus_id", id).order("expiry_date", { ascending: false }),
      ]);
      setBus(b.data); setKm(k.data ?? []); setFuel(f.data ?? []); setMaint(m.data ?? []);
      setFastag(ft.data); setRecharges(rc.data ?? []); setFc(fcs.data ?? []);
    })();
  }, [id]);

  if (!bus) return <p>Loading…</p>;

  const totalKm = km.reduce((s, l) => s + Number(l.distance ?? (Number(l.closing_km || 0) - Number(l.opening_km || 0))), 0);
  const totalFuelL = fuel.reduce((s, l) => s + Number(l.litres || 0), 0) +
                     km.reduce((s, l) => s + Number(l.diesel_litres || 0), 0);
  const totalFuelCost = fuel.reduce((s, l) => s + Number(l.cost || 0), 0) +
                        km.reduce((s, l) => s + Number(l.amount || 0), 0);
  const mileage = totalFuelL > 0 ? (totalKm / totalFuelL).toFixed(2) : "—";
  const totalRecharge = recharges.reduce((s, r) => s + Number(r.amount || 0), 0);
  const totalMaint = maint.reduce((s, m) => s + Number(m.amount || 0), 0);
  const nextService = maint[0]?.date ? new Date(new Date(maint[0].date).getTime() + 90 * 86400000).toISOString().slice(0, 10) : "—";

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Link to="/transport"><Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button></Link>
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Bus {bus.internal_bus_number}</h1>
          <p className="text-muted-foreground text-sm">{bus.number_plate} · {bus.driver || "No driver"} · {bus.routes?.route_name || "No route"}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total KM" value={totalKm.toFixed(0)} icon={Gauge} variant="primary" />
        <StatCard label="Fuel Used" value={`${totalFuelL.toFixed(0)} L`} icon={Fuel} variant="warning" />
        <StatCard label="Mileage" value={`${mileage}`} icon={Gauge} variant="success" />
        <StatCard label="Fuel Cost" value={`₹${totalFuelCost.toFixed(0)}`} icon={Fuel} />
        <StatCard label="FASTag Spend" value={`₹${totalRecharge.toFixed(0)}`} icon={CreditCard} />
        <StatCard label="Maintenance" value={`₹${totalMaint.toFixed(0)}`} icon={Wrench} />
        <StatCard label="FASTag Bal" value={`₹${Number(fastag?.current_balance ?? 0).toFixed(0)}`} icon={CreditCard} variant={Number(fastag?.current_balance ?? 0) < 200 ? "warning" : "primary"} />
        <StatCard label="Next Service" value={nextService} icon={Wrench} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="card-modern p-5">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><Fuel className="w-4 h-4" />Fuel Logs</h3>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {fuel.length === 0 && <p className="text-sm text-muted-foreground">No fuel logs</p>}
            {fuel.map(f => (
              <div key={f.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium">{f.date} · {f.litres}L · ₹{f.cost}</p>
                  <p className="text-xs text-muted-foreground">Odo: {f.odometer ?? "—"}</p>
                </div>
                {f.bill_image && <a href={f.bill_image} target="_blank" rel="noreferrer"><ImageIcon className="w-5 h-5 text-primary" /></a>}
              </div>
            ))}
          </div>
        </Card>

        <Card className="card-modern p-5">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><Wrench className="w-4 h-4" />Maintenance</h3>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {maint.length === 0 && <p className="text-sm text-muted-foreground">No maintenance records</p>}
            {maint.map(m => (
              <div key={m.id} className="p-3 rounded-xl bg-muted/40">
                <p className="text-sm font-medium">{m.date} · {m.item_description}</p>
                <p className="text-xs text-muted-foreground">{m.vendor_name} · ₹{m.amount} {m.bill_no && `· #${m.bill_no}`}</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3">Next service estimate: <strong>{nextService}</strong></p>
        </Card>

        <Card className="card-modern p-5">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><CreditCard className="w-4 h-4" />FASTag</h3>
          <div className="flex items-center justify-between mb-3 p-3 rounded-xl bg-primary/5">
            <span className="text-sm">Current balance</span>
            <Badge>₹{Number(fastag?.current_balance ?? 0).toFixed(0)}</Badge>
          </div>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {recharges.map(r => (
              <div key={r.id} className="p-2 rounded-lg bg-muted/40 flex justify-between text-sm">
                <span>{r.date}</span><span>₹{r.amount}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="card-modern p-5">
          <h3 className="font-semibold mb-3">Fitness Certificates</h3>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {fc.length === 0 && <p className="text-sm text-muted-foreground">No FC on record</p>}
            {fc.map(c => {
              const dl = Math.ceil((new Date(c.expiry_date).getTime() - Date.now()) / 86400000);
              return (
                <div key={c.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium">FC {c.fc_number || "—"}</p>
                    <p className="text-xs text-muted-foreground">Expires {c.expiry_date}</p>
                  </div>
                  <Badge variant={dl < 0 ? "destructive" : dl < 30 ? "secondary" : "default"}>
                    {dl < 0 ? `Expired` : `${dl}d`}
                  </Badge>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}
