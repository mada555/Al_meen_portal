import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { BrandLogo } from "@/components/BrandLogo";
import { z } from "zod";

const studentSchema = z.object({
  name: z.string().trim().min(1).max(100),
  rollNumber: z.string().trim().min(1).max(50),
  password: z.string().min(6).max(72),
});
const adultSchema = z.object({
  name: z.string().trim().min(1).max(100),
  contact: z.string().trim().min(3).max(255),
  password: z.string().min(6).max(72),
});

export default function Auth() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [signupRole, setSignupRole] = useState<"student" | "teacher" | "parent">("student");

  if (loading) return null;
  if (user) return <Navigate to="/" replace />;

  const synthEmail = (id: string, type: string) => {
    const safe = id.toLowerCase().replace(/[^a-z0-9]/g, "");
    return type === "email" ? id : `${safe}@svm.portal`;
  };

  const handleSignIn = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const id = String(fd.get("identifier") || "").trim();
    const password = String(fd.get("password") || "");
    const idType = id.includes("@") ? "email" : /^\d/.test(id) && id.length >= 8 ? "phone" : "roll";
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: synthEmail(id, idType), password,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Welcome back");
    navigate("/");
  };

  const handleSignUp = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    try {
      let identifier = "", identifier_type: "roll" | "phone" | "email" = "email", name = "", password = "";
      if (signupRole === "student") {
        const v = studentSchema.parse({
          name: fd.get("name"), rollNumber: fd.get("rollNumber"), password: fd.get("password"),
        });
        name = v.name; identifier = v.rollNumber; identifier_type = "roll"; password = v.password;
      } else {
        const v = adultSchema.parse({
          name: fd.get("name"), contact: fd.get("contact"), password: fd.get("password"),
        });
        name = v.name; identifier = v.contact; password = v.password;
        identifier_type = v.contact.includes("@") ? "email" : "phone";
      }
      const email = synthEmail(identifier, identifier_type);
      const { error } = await supabase.auth.signUp({
        email, password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: { name, identifier, identifier_type, signup_role: signupRole },
        },
      });
      if (error) throw error;
      toast.success("Account created. Signing you in…");
      await supabase.auth.signInWithPassword({ email, password });
      navigate("/");
    } catch (err: any) {
      toast.error(err.message ?? "Signup failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <Card className="w-full max-w-md p-8 card-modern">
        <div className="flex flex-col items-center mb-6">
          <BrandLogo className="w-full max-w-[280px] h-auto mb-3" />
          <h1 className="text-xl font-bold mt-2">SVM Portal</h1>
          <p className="text-sm text-muted-foreground">School ERP & Operations</p>
        </div>

        <Tabs value={mode} onValueChange={(v) => setMode(v as any)} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>

          <TabsContent value="signin">
            <form onSubmit={handleSignIn} className="space-y-4 mt-4">
              <div>
                <Label>Roll Number / Phone / Email</Label>
                <Input name="identifier" required />
              </div>
              <div>
                <Label>Password</Label>
                <Input name="password" type="password" required />
              </div>
              <Button type="submit" className="w-full" disabled={busy}>
                {busy && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} Sign In
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup">
            <form onSubmit={handleSignUp} className="space-y-4 mt-4">
              <div>
                <Label>I am a</Label>
                <Select value={signupRole} onValueChange={(v) => setSignupRole(v as any)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="teacher">Teacher</SelectItem>
                    <SelectItem value="parent">Parent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Full Name</Label>
                <Input name="name" required maxLength={100} />
              </div>
              {signupRole === "student" ? (
                <div>
                  <Label>Roll Number</Label>
                  <Input name="rollNumber" required maxLength={50} />
                </div>
              ) : (
                <div>
                  <Label>Phone or Email</Label>
                  <Input name="contact" required maxLength={255} />
                </div>
              )}
              <div>
                <Label>Password</Label>
                <Input name="password" type="password" required minLength={6} />
              </div>
              <Button type="submit" className="w-full" disabled={busy}>
                {busy && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} Create Account
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                The first user becomes Admin. New accounts wait for approval.
              </p>
            </form>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}
