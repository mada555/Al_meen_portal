import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { StatCard } from "@/components/StatCard";
import { Plus, Pencil, Trash2, LogIn as LogInIcon, LogOut as LogOutIcon, Clock, UserCheck, UserX, AlertCircle, Download } from "lucide-react";
import { toast } from "sonner";
import { format, subDays } from "date-fns";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { exportXlsx } from "@/lib/exportXlsx";

const STAFF_CATEGORIES = [
  { key: "non_teaching", label: "Non-Teaching" },
  { key: "office", label: "Office Admin" },
  { key: "helper", label: "Helpers" },
  { key: "driver", label: "Drivers" },
] as const;

const LATE_THRESHOLD = "09:15";

function calcStatus(inTime: string | null, manual?: string) {
  if (manual && manual !== "auto") return manual;
  if (!inTime) return "Absent";
  return inTime > LATE_THRESHOLD ? "Late" : "Present";
}
function hours(inT?: string | null, outT?: string | null) {
  if (!inT || !outT) return "—";
  const [ih, im] = inT.split(":").map(Number);
  const [oh, om] = outT.split(":").map(Number);
  const mins = (oh * 60 + om) - (ih * 60 + im);
  if (mins <= 0) return "—";
  return `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

export default function Attendance() {
  const { primaryRole } = useAuth();
  const isAdmin = primaryRole === "admin";
  const isTeacher = primaryRole === "teacher";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold">Attendance</h1>
        <p className="text-muted-foreground">Teachers · Office Staff · In/Out tracking</p>
      </div>
      <Tabs defaultValue={isTeacher ? "me" : "teaching"}>
        <TabsList className="flex-wrap h-auto">
          {isTeacher && <TabsTrigger value="me">My Attendance</TabsTrigger>}
          {(isAdmin || primaryRole === "principal") && <TabsTrigger value="teaching">Teaching Staff</TabsTrigger>}
          {(isAdmin || primaryRole === "principal") && STAFF_CATEGORIES.map(c => (
            <TabsTrigger key={c.key} value={c.key}>{c.label}</TabsTrigger>
          ))}
          {(isAdmin || primaryRole === "principal") && <TabsTrigger value="dash">Overview</TabsTrigger>}
        </TabsList>
        {isTeacher && <TabsContent value="me"><MyAttendance /></TabsContent>}
        <TabsContent value="teaching"><TeacherList canEdit={isAdmin} /></TabsContent>
        {STAFF_CATEGORIES.map(c => (
          <TabsContent key={c.key} value={c.key}><StaffList canEdit={isAdmin} category={c.key} label={c.label} /></TabsContent>
        ))}
        <TabsContent value="dash"><OverviewTab /></TabsContent>
      </Tabs>
    </div>
  );
}

function MyAttendance() {
  const { user } = useAuth();
  const [today, setToday] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const date = format(new Date(), "yyyy-MM-dd");

  const load = async () => {
    if (!user) return;
    const [{ data: t }, { data: h }] = await Promise.all([
      supabase.from("teacher_attendance").select("*").eq("teacher_id", user.id).eq("date", date).maybeSingle(),
      supabase.from("teacher_attendance").select("*").eq("teacher_id", user.id).order("date", { ascending: false }).limit(30),
    ]);
    setToday(t); setHistory(h ?? []);
  };
  useEffect(() => { load(); }, [user]);

  const checkIn = async () => {
    const now = format(new Date(), "HH:mm");
    const status = calcStatus(now);
    const { error } = await supabase.from("teacher_attendance").insert({ teacher_id: user!.id, date, in_time: now, status });
    if (error) return toast.error(error.message);
    toast.success(`Checked in (${status})`); load();
  };
  const checkOut = async () => {
    const now = format(new Date(), "HH:mm");
    const { error } = await supabase.from("teacher_attendance").update({ out_time: now }).eq("id", today.id);
    if (error) return toast.error(error.message);
    toast.success("Checked out"); load();
  };

  return (
    <div className="space-y-4 mt-4">
      <Card className="card-modern p-6">
        <p className="text-sm text-muted-foreground">{format(new Date(), "EEEE, MMM d")}</p>
        <div className="grid grid-cols-3 gap-3 my-4">
          <div><p className="text-xs text-muted-foreground">In</p><p className="text-lg font-semibold">{today?.in_time ?? "—"}</p></div>
          <div><p className="text-xs text-muted-foreground">Out</p><p className="text-lg font-semibold">{today?.out_time ?? "—"}</p></div>
          <div><p className="text-xs text-muted-foreground">Status</p><Badge>{today?.status ?? "Not marked"}</Badge></div>
        </div>
        <div className="flex gap-2">
          <Button onClick={checkIn} disabled={!!today?.in_time} className="flex-1"><LogInIcon className="w-4 h-4 mr-2" />Check In</Button>
          <Button onClick={checkOut} disabled={!today?.in_time || !!today?.out_time} variant="secondary" className="flex-1"><LogOutIcon className="w-4 h-4 mr-2" />Check Out</Button>
        </div>
        {today?.in_time && today?.out_time && <p className="text-xs text-center text-muted-foreground mt-3">Worked: {hours(today.in_time, today.out_time)}</p>}
      </Card>

      <Card className="card-modern p-5">
        <h3 className="font-semibold mb-3">Last 30 days</h3>
        <div className="space-y-2">
          {history.map(h => (
            <div key={h.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center text-sm">
              <span>{h.date}</span>
              <span className="text-muted-foreground"><Clock className="w-3 h-3 inline mr-1" />{h.in_time ?? "—"} → {h.out_time ?? "—"}</span>
              <Badge variant={h.status === "Absent" ? "destructive" : h.status === "Late" ? "secondary" : "default"}>{h.status}</Badge>
            </div>
          ))}
          {history.length === 0 && <p className="text-sm text-muted-foreground">No history yet</p>}
        </div>
      </Card>
    </div>
  );
}

function TeacherList({ canEdit }: { canEdit: boolean }) {
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [list, setList] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);

  const load = async () => {
    const [{ data: a }, { data: t }] = await Promise.all([
      supabase.from("teacher_attendance").select("*").eq("date", date).order("in_time"),
      supabase.from("user_roles").select("user_id, profiles!inner(id,name,identifier)").eq("role", "teacher"),
    ]);
    const profs = (t ?? []).map((r: any) => r.profiles).filter(Boolean);
    setTeachers(profs);
    setList((a ?? []).map((row: any) => ({ ...row, name: profs.find((p: any) => p.id === row.teacher_id)?.name ?? "Unknown" })));
  };
  useEffect(() => { load(); }, [date]);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const inT = String(fd.get("in") || "") || null;
    const outT = String(fd.get("out") || "") || null;
    const manual = String(fd.get("status") || "auto");
    const status = calcStatus(inT, manual);
    const payload: any = { teacher_id: String(fd.get("teacher_id")), date: String(fd.get("date")), in_time: inT, out_time: outT, status };
    const { error } = editing
      ? await supabase.from("teacher_attendance").update(payload).eq("id", editing.id)
      : await supabase.from("teacher_attendance").insert(payload);
    if (error) return toast.error(error.message);
    setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("teacher_attendance").delete().eq("id", id); load(); };
  const exportMonth = async () => {
    const since = format(subDays(new Date(), 30), "yyyy-MM-dd");
    const { data } = await supabase.from("teacher_attendance").select("*").gte("date", since).order("date", { ascending: false });
    const named = (data ?? []).map((r: any) => ({ Date: r.date, Teacher: teachers.find((t: any) => t.id === r.teacher_id)?.name ?? r.teacher_id, In: r.in_time, Out: r.out_time, Status: r.status }));
    exportXlsx(named, `teaching-attendance-${Date.now()}.xlsx`, "Teaching");
  };

  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex flex-wrap justify-between items-center gap-2 mb-4">
        <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-auto" />
        <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={exportMonth}><Download className="w-4 h-4 mr-1" />Excel</Button>
        {canEdit && (
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
            <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-1" />Mark</Button></DialogTrigger>
            <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "Mark"} Teacher Attendance</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <Select name="teacher_id" defaultValue={editing?.teacher_id}><SelectTrigger><SelectValue placeholder="Teacher" /></SelectTrigger>
                  <SelectContent>{teachers.map((t: any) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent>
                </Select>
                <Input name="date" type="date" defaultValue={editing?.date ?? date} required />
                <div className="grid grid-cols-2 gap-2">
                  <Input name="in" type="time" defaultValue={editing?.in_time ?? ""} placeholder="In" />
                  <Input name="out" type="time" defaultValue={editing?.out_time ?? ""} placeholder="Out" />
                </div>
                <Select name="status" defaultValue="auto">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto (by in-time)</SelectItem>
                    <SelectItem value="Present">Present</SelectItem>
                    <SelectItem value="Late">Late</SelectItem>
                    <SelectItem value="Absent">Absent</SelectItem>
                  </SelectContent>
                </Select>
                <Button type="submit" className="w-full">Save</Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
        </div>
      </div>
      <div className="space-y-2">
        {list.map(r => (
          <div key={r.id} className="p-3 rounded-xl bg-muted/40 flex flex-wrap justify-between items-center gap-2">
            <div>
              <p className="font-medium">{r.name}</p>
              <p className="text-xs text-muted-foreground">In {r.in_time ?? "—"} · Out {r.out_time ?? "—"} · {hours(r.in_time, r.out_time)}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={r.status === "Absent" ? "destructive" : r.status === "Late" ? "secondary" : "default"}>{r.status}</Badge>
              {canEdit && <>
                <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="w-4 h-4" /></Button>
              </>}
            </div>
          </div>
        ))}
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No records</p>}
      </div>
    </Card>
  );
}

function StaffList({ canEdit, category = "office", label = "Staff" }: { canEdit: boolean; category?: string; label?: string }) {
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [list, setList] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const load = async () => {
    const { data } = await supabase.from("staff_attendance").select("*").eq("date", date).eq("category", category).order("in_time");
    setList(data ?? []);
  };
  useEffect(() => { load(); }, [date, category]);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const inT = String(fd.get("in") || "") || null;
    const outT = String(fd.get("out") || "") || null;
    const manual = String(fd.get("status") || "auto");
    const status = calcStatus(inT, manual);
    const payload: any = {
      staff_name: String(fd.get("name")), role: String(fd.get("role") || ""),
      category,
      date: String(fd.get("date")), in_time: inT, out_time: outT, status,
    };
    const { error } = editing
      ? await supabase.from("staff_attendance").update(payload).eq("id", editing.id)
      : await supabase.from("staff_attendance").insert(payload);
    if (error) return toast.error(error.message);
    setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("staff_attendance").delete().eq("id", id); load(); };
  const exportMonth = async () => {
    const since = format(subDays(new Date(), 30), "yyyy-MM-dd");
    const { data } = await supabase.from("staff_attendance").select("*").eq("category", category).gte("date", since).order("date", { ascending: false });
    exportXlsx((data ?? []).map(r => ({ Date: r.date, Name: r.staff_name, Role: r.role, In: r.in_time, Out: r.out_time, Status: r.status })), `${category}-attendance-${Date.now()}.xlsx`, label);
  };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex flex-wrap justify-between items-center gap-2 mb-4">
        <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-auto" />
        <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={exportMonth}><Download className="w-4 h-4 mr-1" />Excel</Button>
        {canEdit && (
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
            <DialogTrigger asChild><Button size="sm"><Plus className="w-4 h-4 mr-1" />Mark</Button></DialogTrigger>
            <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "Mark"} Staff Attendance</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <Input name="name" placeholder="Staff name" defaultValue={editing?.staff_name} required />
                <Input name="role" placeholder="Role (e.g. Clerk, Peon)" defaultValue={editing?.role} />
                <Input name="date" type="date" defaultValue={editing?.date ?? date} required />
                <div className="grid grid-cols-2 gap-2">
                  <Input name="in" type="time" defaultValue={editing?.in_time ?? ""} />
                  <Input name="out" type="time" defaultValue={editing?.out_time ?? ""} />
                </div>
                <Select name="status" defaultValue="auto">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto</SelectItem>
                    <SelectItem value="Present">Present</SelectItem>
                    <SelectItem value="Late">Late</SelectItem>
                    <SelectItem value="Absent">Absent</SelectItem>
                  </SelectContent>
                </Select>
                <Button type="submit" className="w-full">Save</Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
        </div>
      </div>
      <div className="space-y-2">
        {list.map(r => (
          <div key={r.id} className="p-3 rounded-xl bg-muted/40 flex flex-wrap justify-between items-center gap-2">
            <div>
              <p className="font-medium">{r.staff_name} <span className="text-xs text-muted-foreground">{r.role}</span></p>
              <p className="text-xs text-muted-foreground">In {r.in_time ?? "—"} · Out {r.out_time ?? "—"} · {hours(r.in_time, r.out_time)}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={r.status === "Absent" ? "destructive" : r.status === "Late" ? "secondary" : "default"}>{r.status}</Badge>
              {canEdit && <>
                <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="w-4 h-4" /></Button>
              </>}
            </div>
          </div>
        ))}
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No records</p>}
      </div>
    </Card>
  );
}

function OverviewTab() {
  const [tStats, setTStats] = useState({ p: 0, l: 0, a: 0 });
  const [sStats, setSStats] = useState({ p: 0, l: 0, a: 0 });
  const [trend, setTrend] = useState<any[]>([]);
  const date = format(new Date(), "yyyy-MM-dd");

  useEffect(() => {
    (async () => {
      const [{ data: t }, { data: s }] = await Promise.all([
        supabase.from("teacher_attendance").select("status").eq("date", date),
        supabase.from("staff_attendance").select("status").eq("date", date),
      ]);
      const sum = (rows: any[]) => ({
        p: rows.filter(r => r.status === "Present").length,
        l: rows.filter(r => r.status === "Late").length,
        a: rows.filter(r => r.status === "Absent").length,
      });
      setTStats(sum(t ?? [])); setSStats(sum(s ?? []));

      const days = Array.from({ length: 7 }, (_, i) => format(subDays(new Date(), 6 - i), "yyyy-MM-dd"));
      const { data: week } = await supabase.from("teacher_attendance").select("date,status").in("date", days);
      const map: Record<string, { present: number; late: number; absent: number }> = {};
      days.forEach(d => map[d] = { present: 0, late: 0, absent: 0 });
      (week ?? []).forEach((r: any) => {
        if (r.status === "Present") map[r.date].present++;
        else if (r.status === "Late") map[r.date].late++;
        else if (r.status === "Absent") map[r.date].absent++;
      });
      setTrend(days.map(d => ({ day: format(new Date(d), "EEE"), ...map[d] })));
    })();
  }, []);

  return (
    <div className="space-y-4 mt-4">
      <div className="grid grid-cols-3 gap-3">
        <StatCard label="Teachers Present" value={tStats.p} icon={UserCheck} variant="success" />
        <StatCard label="Teachers Late" value={tStats.l} icon={AlertCircle} variant="warning" />
        <StatCard label="Teachers Absent" value={tStats.a} icon={UserX} />
      </div>
      <div className="grid grid-cols-3 gap-3">
        <StatCard label="Staff Present" value={sStats.p} icon={UserCheck} variant="success" />
        <StatCard label="Staff Late" value={sStats.l} icon={AlertCircle} variant="warning" />
        <StatCard label="Staff Absent" value={sStats.a} icon={UserX} />
      </div>
      <Card className="card-modern p-5">
        <h3 className="font-semibold mb-3">Teacher attendance — last 7 days</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trend}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 12 }} />
              <Bar dataKey="present" stackId="a" fill="hsl(var(--primary))" radius={[0,0,0,0]} />
              <Bar dataKey="late" stackId="a" fill="hsl(var(--warning))" />
              <Bar dataKey="absent" stackId="a" fill="hsl(var(--destructive))" radius={[8,8,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
