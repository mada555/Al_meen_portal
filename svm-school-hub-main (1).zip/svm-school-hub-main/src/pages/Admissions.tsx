import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Download, UserPlus } from "lucide-react";
import { CLASSES } from "@/lib/constants";
import { toast } from "sonner";
import { exportXlsx } from "@/lib/exportXlsx";
import { format, subDays } from "date-fns";
import { StatCard } from "@/components/StatCard";

export default function Admissions() {
  const { primaryRole } = useAuth();
  const canEdit = primaryRole === "admin";
  const [list, setList] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [filter, setFilter] = useState<string>("all");
  const [from, setFrom] = useState(format(subDays(new Date(), 30), "yyyy-MM-dd"));
  const [to, setTo] = useState(format(new Date(), "yyyy-MM-dd"));

  const load = async () => {
    const { data } = await supabase.from("admissions").select("*").order("admission_date", { ascending: false });
    setList(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      admission_date: String(fd.get("date")),
      student_name: String(fd.get("name")),
      grade: String(fd.get("grade")),
      parent_name: String(fd.get("parent") || "") || null,
      contact: String(fd.get("contact") || "") || null,
      remarks: String(fd.get("remarks") || "") || null,
    };
    const { error } = editing
      ? await supabase.from("admissions").update(payload).eq("id", editing.id)
      : await supabase.from("admissions").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("admissions").delete().eq("id", id); load(); };

  const inRange = list.filter(l => l.admission_date >= from && l.admission_date <= to);
  const filtered = filter === "all" ? inRange : inRange.filter(l => l.grade === filter);
  const exportRange = () => exportXlsx(
    filtered.map(a => ({ Date: a.admission_date, Name: a.student_name, Grade: a.grade, Parent: a.parent_name, Contact: a.contact, Remarks: a.remarks })),
    `admissions-${from}_to_${to}.xlsx`, "Admissions"
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold">Admissions</h1>
        <p className="text-muted-foreground">Log new admissions by date and grade</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total in range" value={filtered.length} icon={UserPlus} variant="primary" />
        <StatCard label="All time" value={list.length} icon={UserPlus} />
        <StatCard label="From" value={from} icon={UserPlus} />
        <StatCard label="To" value={to} icon={UserPlus} />
      </div>

      <Card className="card-modern p-5">
        <div className="flex flex-wrap gap-2 justify-between mb-4">
          <div className="flex flex-wrap gap-2 items-center">
            <Input type="date" value={from} onChange={e => setFrom(e.target.value)} className="w-auto" />
            <span className="text-muted-foreground text-sm">to</span>
            <Input type="date" value={to} onChange={e => setTo(e.target.value)} className="w-auto" />
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All grades</SelectItem>
                {CLASSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={exportRange}><Download className="w-4 h-4 mr-1" />Export</Button>
            {canEdit && (
              <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
                <DialogTrigger asChild>
                  <Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />New</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Admission</DialogTitle></DialogHeader>
                  <form onSubmit={submit} className="space-y-3">
                    <Input name="date" type="date" defaultValue={editing?.admission_date ?? new Date().toISOString().split("T")[0]} required />
                    <Input name="name" placeholder="Student Name" defaultValue={editing?.student_name} required />
                    <Select name="grade" defaultValue={editing?.grade ?? "Pre-KG"}>
                      <SelectTrigger><SelectValue placeholder="Grade" /></SelectTrigger>
                      <SelectContent>{CLASSES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                    <Input name="parent" placeholder="Parent Name" defaultValue={editing?.parent_name} />
                    <Input name="contact" placeholder="Contact" defaultValue={editing?.contact} />
                    <Input name="remarks" placeholder="Remarks" defaultValue={editing?.remarks} />
                    <Button type="submit" className="w-full">Save</Button>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>
        <div className="space-y-2">
          {filtered.map(a => (
            <div key={a.id} className="p-3 rounded-xl bg-muted/40 flex flex-wrap justify-between gap-2 items-center">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-medium">{a.student_name}</p>
                  <Badge variant="outline">{a.grade}</Badge>
                  <Badge variant="secondary">{a.admission_date}</Badge>
                </div>
                <p className="text-xs text-muted-foreground">{a.parent_name || "—"} · {a.contact || "—"}{a.remarks ? ` · ${a.remarks}` : ""}</p>
              </div>
              {canEdit && (
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(a); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(a.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              )}
            </div>
          ))}
          {filtered.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No admissions yet</p>}
        </div>
      </Card>
    </div>
  );
}
