import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Trash2, Pencil } from "lucide-react";
import { toast } from "sonner";

export default function Kitchen() {
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl lg:text-3xl font-bold">Kitchen</h1><p className="text-muted-foreground">Stock · Purchases · Gas</p></div>
      <Tabs defaultValue="stock">
        <TabsList><TabsTrigger value="stock">Stock</TabsTrigger><TabsTrigger value="purchases">Purchases</TabsTrigger><TabsTrigger value="gas">Gas</TabsTrigger></TabsList>
        <TabsContent value="stock"><StockTab /></TabsContent>
        <TabsContent value="purchases"><PurchasesTab /></TabsContent>
        <TabsContent value="gas"><GasTab /></TabsContent>
      </Tabs>
    </div>
  );
}

function StockTab() {
  const [list, setList] = useState<any[]>([]); const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const load = async () => { const { data } = await supabase.from("kitchen_items").select("*").order("name"); setList(data ?? []); };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = { name: String(fd.get("name")), stock: Number(fd.get("stock") || 0), unit: String(fd.get("unit") || "kg") };
    const { error } = editing
      ? await supabase.from("kitchen_items").update(payload).eq("id", editing.id)
      : await supabase.from("kitchen_items").insert(payload);
    if (error) return toast.error(error.message);
    setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("kitchen_items").delete().eq("id", id); load(); };
  const update = async (id: string, stock: number) => {
    await supabase.from("kitchen_items").update({ stock }).eq("id", id); load();
  };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add Item</Button></DialogTrigger>
          <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Item</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Input name="name" placeholder="Item name" defaultValue={editing?.name} required />
              <Input name="stock" type="number" step="0.01" placeholder="Stock" defaultValue={editing?.stock ?? 0} />
              <Input name="unit" placeholder="Unit (kg, L, pcs)" defaultValue={editing?.unit ?? "kg"} />
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="space-y-2">
        {list.map(i => (
          <div key={i.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center gap-2">
            <div className="flex-1"><p className="font-medium">{i.name}</p><p className="text-xs text-muted-foreground">{i.unit}</p></div>
            <Input type="number" defaultValue={i.stock} className="w-24"
              onBlur={(e) => Number(e.target.value) !== Number(i.stock) && update(i.id, Number(e.target.value))} />
            {Number(i.stock) < 5 && <Badge variant="destructive">Low</Badge>}
            <Button size="icon" variant="ghost" onClick={() => { setEditing(i); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
            <Button size="icon" variant="ghost" onClick={() => del(i.id)}><Trash2 className="w-4 h-4" /></Button>
          </div>
        ))}
      </div>
    </Card>
  );
}

function PurchasesTab() {
  const [list, setList] = useState<any[]>([]); const [open, setOpen] = useState(false);
  const load = async () => { const { data } = await supabase.from("kitchen_purchases").select("*").order("date", { ascending: false }).limit(50); setList(data ?? []); };
  useEffect(() => { load(); }, []);
  const [editing, setEditing] = useState<any>(null);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = { item_name: String(fd.get("item")), qty: Number(fd.get("qty")), cost: Number(fd.get("cost")) };
    const { error } = editing
      ? await supabase.from("kitchen_purchases").update(payload).eq("id", editing.id)
      : await supabase.from("kitchen_purchases").insert(payload);
    if (error) return toast.error(error.message);
    setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("kitchen_purchases").delete().eq("id", id); load(); };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Log Purchase</Button></DialogTrigger>
          <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Purchase</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Input name="item" placeholder="Item" defaultValue={editing?.item_name} required />
              <Input name="qty" type="number" step="0.01" placeholder="Quantity" defaultValue={editing?.qty} required />
              <Input name="cost" type="number" step="0.01" placeholder="Cost (₹)" defaultValue={editing?.cost} required />
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="space-y-2">
        {list.map(p => (
          <div key={p.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center gap-2">
            <div><p className="font-medium">{p.item_name}</p><p className="text-xs text-muted-foreground">{p.date} · {p.qty}</p></div>
            <div className="flex items-center gap-2">
              <Badge>₹{p.cost}</Badge>
              <Button size="icon" variant="ghost" onClick={() => { setEditing(p); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => del(p.id)}><Trash2 className="w-4 h-4" /></Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function GasTab() {
  const [list, setList] = useState<any[]>([]); const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const load = async () => { const { data } = await supabase.from("gas_logs").select("*").order("date", { ascending: false }).limit(50); setList(data ?? []); };
  useEffect(() => { load(); }, []);
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = { cylinders: Number(fd.get("cyl")), cost: Number(fd.get("cost")) };
    const { error } = editing
      ? await supabase.from("gas_logs").update(payload).eq("id", editing.id)
      : await supabase.from("gas_logs").insert(payload);
    if (error) return toast.error(error.message);
    setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("gas_logs").delete().eq("id", id); load(); };
  return (
    <Card className="card-modern p-5 mt-4">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Log Gas</Button></DialogTrigger>
          <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Gas Log</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Input name="cyl" type="number" step="0.01" placeholder="Cylinders" defaultValue={editing?.cylinders} required />
              <Input name="cost" type="number" step="0.01" placeholder="Cost (₹)" defaultValue={editing?.cost} required />
              <Button type="submit" className="w-full">Save</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="space-y-2">
        {list.map(g => (
          <div key={g.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-center gap-2">
            <p className="font-medium">{g.date}</p>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{g.cylinders} cyl</Badge>
              <Badge>₹{g.cost}</Badge>
              <Button size="icon" variant="ghost" onClick={() => { setEditing(g); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => del(g.id)}><Trash2 className="w-4 h-4" /></Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
