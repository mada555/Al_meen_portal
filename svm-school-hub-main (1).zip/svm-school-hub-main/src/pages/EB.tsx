import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Trash2, Pencil } from "lucide-react";
import { toast } from "sonner";

export default function EB() {
  const [list, setList] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any>(null);

  const load = async () => {
    const { data } = await supabase.from("eb_readings").select("*").order("date", { ascending: false }).limit(200);
    setList(data ?? []);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const meter = String(fd.get("meter")); const reading = Number(fd.get("reading"));
    const date = String(fd.get("date"));
    const remarks = String(fd.get("remarks") || "");
    let units = 0;
    if (!editing) {
      const { data: prev } = await supabase.from("eb_readings").select("reading")
        .eq("meter", meter).order("date", { ascending: false }).limit(1).maybeSingle();
      units = prev ? reading - Number(prev.reading) : 0;
    } else units = Number(editing.units || 0);
    const payload: any = { meter, reading, units, date, remarks };
    const { error } = editing
      ? await supabase.from("eb_readings").update(payload).eq("id", editing.id)
      : await supabase.from("eb_readings").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Saved"); setOpen(false); setEditing(null); load();
  };
  const del = async (id: string) => { if (!confirm("Delete?")) return; await supabase.from("eb_readings").delete().eq("id", id); load(); };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold">EB Readings</h1>
        <p className="text-muted-foreground">School & College meter register</p>
      </div>
      <Card className="card-modern p-5">
        <div className="flex justify-end mb-4">
          <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditing(null); }}>
            <DialogTrigger asChild><Button size="sm" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-1" />Add Reading</Button></DialogTrigger>
            <DialogContent><DialogHeader><DialogTitle>{editing ? "Edit" : "New"} Reading</DialogTitle></DialogHeader>
              <form onSubmit={submit} className="space-y-3">
                <Select name="meter" defaultValue={editing?.meter ?? "school"}><SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="school">School</SelectItem><SelectItem value="college">College</SelectItem></SelectContent>
                </Select>
                <Input name="date" type="date" defaultValue={editing?.date ?? new Date().toISOString().split("T")[0]} required />
                <Input name="reading" type="number" step="0.01" placeholder="Reading" defaultValue={editing?.reading} required />
                <Input name="remarks" placeholder="Remarks" defaultValue={editing?.remarks ?? ""} />
                <Button type="submit" className="w-full">Save</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Desktop table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-muted-foreground border-b">
                <th className="py-2 px-2">S.No</th><th className="py-2 px-2">Date</th>
                <th className="py-2 px-2">Meter</th><th className="py-2 px-2">Reading</th>
                <th className="py-2 px-2">Units</th><th className="py-2 px-2">Remarks</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map(r => (
                <tr key={r.id} className="border-b last:border-0">
                  <td className="py-2 px-2 font-mono text-xs">{r.serial_no}</td>
                  <td className="py-2 px-2">{r.date}</td>
                  <td className="py-2 px-2 capitalize">{r.meter}</td>
                  <td className="py-2 px-2">{r.reading}</td>
                  <td className="py-2 px-2"><Badge variant="secondary">{r.units}</Badge></td>
                  <td className="py-2 px-2">{r.remarks ?? "—"}</td>
                  <td className="py-2 px-2 text-right whitespace-nowrap">
                    <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="w-4 h-4" /></Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile list */}
        <div className="md:hidden space-y-2">
          {list.map(r => (
            <div key={r.id} className="p-3 rounded-xl bg-muted/40 flex justify-between items-start">
              <div className="text-sm">
                <p className="font-medium capitalize">#{r.serial_no} · {r.meter}</p>
                <p className="text-xs text-muted-foreground">{r.date} · Reading {r.reading} · {r.units} units</p>
                {r.remarks && <p className="text-xs mt-1">{r.remarks}</p>}
              </div>
              <div className="flex gap-1">
                <Button size="icon" variant="ghost" onClick={() => { setEditing(r); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="w-4 h-4" /></Button>
              </div>
            </div>
          ))}
        </div>
        {list.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No readings yet</p>}
      </Card>
    </div>
  );
}
