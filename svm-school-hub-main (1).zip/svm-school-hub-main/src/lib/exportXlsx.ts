import * as XLSX from "xlsx";

export function exportXlsx(rows: any[], filename: string, sheet = "Sheet1") {
  if (!rows || rows.length === 0) {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet([{ note: "No data" }]), sheet);
    XLSX.writeFile(wb, filename);
    return;
  }
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), sheet.slice(0, 30));
  XLSX.writeFile(wb, filename);
}
