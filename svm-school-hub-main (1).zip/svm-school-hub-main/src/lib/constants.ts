export const CLASSES = ["Pre-KG","LKG","UKG","I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"];
export const SECTIONS = ["A","B","C"];
