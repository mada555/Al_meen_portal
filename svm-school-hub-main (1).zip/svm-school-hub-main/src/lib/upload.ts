import { supabase } from "@/integrations/supabase/client";

export async function uploadFile(file: File, folder = "misc"): Promise<string | null> {
  if (!file) return null;
  const ext = file.name.split(".").pop();
  const path = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from("svm-uploads").upload(path, file, { upsert: false });
  if (error) { console.error(error); return null; }
  const { data } = supabase.storage.from("svm-uploads").getPublicUrl(path);
  return data.publicUrl;
}
