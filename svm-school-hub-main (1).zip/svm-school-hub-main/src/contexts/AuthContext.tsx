import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";

export type AppRole = "admin" | "principal" | "chairman" | "teacher" | "student" | "parent" | "pending";
export type UserStatus = "pending" | "approved" | "rejected";

interface Profile {
  id: string;
  name: string;
  identifier: string;
  identifier_type: string;
  status: UserStatus;
}

interface AuthCtx {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  roles: AppRole[];
  primaryRole: AppRole | null;
  loading: boolean;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
}

const Ctx = createContext<AuthCtx>({} as AuthCtx);
export const useAuth = () => useContext(Ctx);

const ROLE_PRIORITY: AppRole[] = ["admin", "chairman", "principal", "teacher", "parent", "student", "pending"];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);

  const loadUserData = async (uid: string) => {
    const [{ data: prof }, { data: rs }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", uid).maybeSingle(),
      supabase.from("user_roles").select("role").eq("user_id", uid),
    ]);
    setProfile(prof as any);
    setRoles((rs ?? []).map((r: any) => r.role));
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) setTimeout(() => loadUserData(s.user.id), 0);
      else { setProfile(null); setRoles([]); }
    });
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) loadUserData(s.user.id).finally(() => setLoading(false));
      else setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const primaryRole = ROLE_PRIORITY.find(r => roles.includes(r)) ?? null;

  return (
    <Ctx.Provider value={{
      user, session, profile, roles, primaryRole, loading,
      signOut: async () => { await supabase.auth.signOut(); },
      refresh: async () => { if (user) await loadUserData(user.id); },
    }}>
      {children}
    </Ctx.Provider>
  );
}
