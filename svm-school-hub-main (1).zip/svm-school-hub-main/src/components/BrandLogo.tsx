import logo from "@/assets/svm-logo.jpg";
import { cn } from "@/lib/utils";

export function BrandLogo({ className }: { className?: string }) {
  return <img src={logo} alt="Shazammal Vidhya Mandhir" className={cn("object-contain", className)} />;
}
