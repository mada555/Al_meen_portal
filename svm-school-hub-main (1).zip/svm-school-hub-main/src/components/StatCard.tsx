import { ReactNode } from "react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface Props {
  label: string;
  value: ReactNode;
  icon: any;
  trend?: string;
  variant?: "default" | "primary" | "success" | "warning";
}
const variantBg: Record<string, string> = {
  default: "bg-muted text-foreground",
  primary: "gradient-primary text-primary-foreground",
  success: "gradient-success text-success-foreground",
  warning: "gradient-warning text-warning-foreground",
};

export function StatCard({ label, value, icon: Icon, trend, variant = "default" }: Props) {
  return (
    <Card className="card-modern p-4 lg:p-5 flex items-start gap-3">
      <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center shrink-0", variantBg[variant])}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground font-medium">{label}</p>
        <p className="text-2xl font-bold tracking-tight">{value}</p>
        {trend && <p className="text-xs text-muted-foreground mt-0.5">{trend}</p>}
      </div>
    </Card>
  );
}
