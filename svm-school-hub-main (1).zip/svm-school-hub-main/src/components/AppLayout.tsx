import { ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth, AppRole } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  LayoutDashboard, GraduationCap, Bus, Zap, ChefHat, LogOut, ShieldCheck, ClipboardCheck, UserPlus, MessageSquare, IndianRupee, Package,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { BrandLogo } from "@/components/BrandLogo";

interface NavItem { to: string; label: string; icon: any; roles: AppRole[] }

const NAV: NavItem[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, roles: ["admin","principal","chairman","teacher","student","parent"] },
  { to: "/academic", label: "Academic", icon: GraduationCap, roles: ["admin","principal","teacher","student","parent","chairman"] },
  { to: "/attendance", label: "Attendance", icon: ClipboardCheck, roles: ["admin","principal","teacher"] },
  { to: "/admissions", label: "Admissions", icon: UserPlus, roles: ["admin","principal","chairman"] },
  { to: "/enquiries", label: "Enquiries", icon: MessageSquare, roles: ["admin","principal","chairman"] },
  { to: "/fees", label: "Fees", icon: IndianRupee, roles: ["admin","principal","chairman"] },
  { to: "/stock", label: "Stock", icon: Package, roles: ["admin","principal","chairman"] },
  { to: "/transport", label: "Transport", icon: Bus, roles: ["admin","principal","chairman"] },
  { to: "/eb", label: "EB", icon: Zap, roles: ["admin","principal","chairman"] },
  { to: "/kitchen", label: "Kitchen", icon: ChefHat, roles: ["admin","principal","chairman"] },
  { to: "/admin", label: "Admin", icon: ShieldCheck, roles: ["admin"] },
];

export default function AppLayout({ children }: { children: ReactNode }) {
  const { profile, primaryRole, signOut } = useAuth();
  const navigate = useNavigate();
  const items = NAV.filter(n => primaryRole && n.roles.includes(primaryRole));

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-64 border-r bg-card p-4 sticky top-0 h-screen">
        <div className="flex items-center gap-2 mb-8 px-2">
          <BrandLogo className="w-12 h-12 rounded-xl bg-white p-1 shadow-sm" />
          <div>
            <p className="font-bold leading-tight">SVM Portal</p>
            <p className="text-xs text-muted-foreground capitalize">{primaryRole}</p>
          </div>
        </div>
        <nav className="flex-1 space-y-1">
          {items.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} end={to === "/"}
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors",
                isActive ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}>
              <Icon className="w-4 h-4" /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t pt-4 mt-4">
          <div className="flex items-center gap-2 px-2 mb-2">
            <Avatar className="w-8 h-8"><AvatarFallback>{profile?.name?.[0] ?? "?"}</AvatarFallback></Avatar>
            <div className="text-sm overflow-hidden">
              <p className="font-medium truncate">{profile?.name}</p>
              <p className="text-xs text-muted-foreground truncate">{profile?.identifier}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="w-full justify-start" onClick={async () => { await signOut(); navigate("/auth"); }}>
            <LogOut className="w-4 h-4 mr-2" /> Sign out
          </Button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="lg:hidden sticky top-0 z-30 bg-card/80 backdrop-blur border-b px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BrandLogo className="w-9 h-9 rounded-lg bg-white p-0.5" />
            <span className="font-bold">SVM</span>
          </div>
          <Button variant="ghost" size="sm" onClick={async () => { await signOut(); navigate("/auth"); }}>
            <LogOut className="w-4 h-4" />
          </Button>
        </header>

        <main className="flex-1 p-4 lg:p-8 pb-24 lg:pb-8 max-w-7xl w-full mx-auto">
          {children}
        </main>

        {/* Mobile bottom nav */}
        <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-card/95 backdrop-blur border-t">
          <div className="flex overflow-x-auto no-scrollbar">
            {items.map(({ to, label, icon: Icon }) => (
              <NavLink key={to} to={to} end={to === "/"}
                className={({ isActive }) => cn(
                  "flex flex-col items-center gap-1 py-2.5 px-3 text-[10px] font-medium shrink-0 min-w-[64px]",
                  isActive ? "text-primary" : "text-muted-foreground"
                )}>
                <Icon className="w-5 h-5" />
                {label}
              </NavLink>
            ))}
          </div>
        </nav>
      </div>
    </div>
  );
}
