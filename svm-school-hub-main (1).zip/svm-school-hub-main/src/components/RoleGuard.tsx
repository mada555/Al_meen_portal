import { useAuth } from "@/contexts/AuthContext";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { ReactNode } from "react";
import { AppRole } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Hourglass, LogIn } from "lucide-react";

interface Props { children: ReactNode; allowed?: AppRole[]; }
export function RoleGuard({ children, allowed }: Props) {
  const { user, loading, profile, primaryRole, signOut } = useAuth();
  const loc = useLocation();
  const navigate = useNavigate();
  if (loading) return <div className="min-h-screen flex items-center justify-center"><Hourglass className="animate-spin" /></div>;
  if (!user) return <Navigate to="/auth" state={{ from: loc }} replace />;
  if (profile?.status !== "approved") {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="card-modern p-8 max-w-md text-center space-y-4">
          <Hourglass className="w-10 h-10 mx-auto mb-1 text-warning" />
          <h2 className="text-xl font-semibold">Awaiting Approval</h2>
          <p className="text-muted-foreground text-sm">Your account is {profile?.status ?? "pending"}. An admin must approve you before you can access the portal.</p>
          <Button variant="outline" className="w-full" onClick={async () => { await signOut(); navigate("/auth"); }}>
            <LogIn className="w-4 h-4 mr-2" /> Back to Sign in
          </Button>
        </Card>
      </div>
    );
  }
  if (allowed && primaryRole && !allowed.includes(primaryRole)) return <Navigate to="/" replace />;
  return <>{children}</>;
}
