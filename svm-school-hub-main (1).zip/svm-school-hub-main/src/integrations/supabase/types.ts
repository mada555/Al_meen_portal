export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admissions: {
        Row: {
          admission_date: string
          contact: string | null
          created_at: string
          grade: string
          id: string
          parent_name: string | null
          remarks: string | null
          student_name: string
        }
        Insert: {
          admission_date?: string
          contact?: string | null
          created_at?: string
          grade: string
          id?: string
          parent_name?: string | null
          remarks?: string | null
          student_name: string
        }
        Update: {
          admission_date?: string
          contact?: string | null
          created_at?: string
          grade?: string
          id?: string
          parent_name?: string | null
          remarks?: string | null
          student_name?: string
        }
        Relationships: []
      }
      attendance: {
        Row: {
          date: string
          id: string
          marked_by: string | null
          present: boolean
          student_id: string
        }
        Insert: {
          date?: string
          id?: string
          marked_by?: string | null
          present?: boolean
          student_id: string
        }
        Update: {
          date?: string
          id?: string
          marked_by?: string | null
          present?: boolean
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "attendance_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      bus_arrivals: {
        Row: {
          arrival_time: string
          bus_id: string
          date: string
          id: string
          km: number | null
          place_route: string | null
          rank: number | null
        }
        Insert: {
          arrival_time: string
          bus_id: string
          date?: string
          id?: string
          km?: number | null
          place_route?: string | null
          rank?: number | null
        }
        Update: {
          arrival_time?: string
          bus_id?: string
          date?: string
          id?: string
          km?: number | null
          place_route?: string | null
          rank?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "bus_arrivals_bus_id_fkey"
            columns: ["bus_id"]
            isOneToOne: false
            referencedRelation: "buses"
            referencedColumns: ["id"]
          },
        ]
      }
      bus_km_logs: {
        Row: {
          amount: number | null
          bill_image: string | null
          bus_id: string
          closing_km: number
          date: string
          diesel_litres: number | null
          distance: number | null
          id: string
          mileage: number | null
          opening_km: number
        }
        Insert: {
          amount?: number | null
          bill_image?: string | null
          bus_id: string
          closing_km: number
          date?: string
          diesel_litres?: number | null
          distance?: number | null
          id?: string
          mileage?: number | null
          opening_km: number
        }
        Update: {
          amount?: number | null
          bill_image?: string | null
          bus_id?: string
          closing_km?: number
          date?: string
          diesel_litres?: number | null
          distance?: number | null
          id?: string
          mileage?: number | null
          opening_km?: number
        }
        Relationships: [
          {
            foreignKeyName: "bus_km_logs_bus_id_fkey"
            columns: ["bus_id"]
            isOneToOne: false
            referencedRelation: "buses"
            referencedColumns: ["id"]
          },
        ]
      }
      bus_maintenance: {
        Row: {
          amount: number
          bill_no: string | null
          bus_id: string | null
          created_at: string
          date: string
          id: string
          image_url: string | null
          item_description: string
          remarks: string | null
          serial_no: number
          vendor_name: string
        }
        Insert: {
          amount?: number
          bill_no?: string | null
          bus_id?: string | null
          created_at?: string
          date?: string
          id?: string
          image_url?: string | null
          item_description: string
          remarks?: string | null
          serial_no?: number
          vendor_name: string
        }
        Update: {
          amount?: number
          bill_no?: string | null
          bus_id?: string | null
          created_at?: string
          date?: string
          id?: string
          image_url?: string | null
          item_description?: string
          remarks?: string | null
          serial_no?: number
          vendor_name?: string
        }
        Relationships: []
      }
      buses: {
        Row: {
          driver: string | null
          id: string
          internal_bus_number: string
          number_plate: string
          route_id: string | null
        }
        Insert: {
          driver?: string | null
          id?: string
          internal_bus_number: string
          number_plate: string
          route_id?: string | null
        }
        Update: {
          driver?: string | null
          id?: string
          internal_bus_number?: string
          number_plate?: string
          route_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "buses_route_id_fkey"
            columns: ["route_id"]
            isOneToOne: false
            referencedRelation: "routes"
            referencedColumns: ["id"]
          },
        ]
      }
      eb_readings: {
        Row: {
          date: string
          id: string
          meter: string
          reading: number
          remarks: string | null
          serial_no: number
          units: number | null
        }
        Insert: {
          date?: string
          id?: string
          meter: string
          reading: number
          remarks?: string | null
          serial_no?: number
          units?: number | null
        }
        Update: {
          date?: string
          id?: string
          meter?: string
          reading?: number
          remarks?: string | null
          serial_no?: number
          units?: number | null
        }
        Relationships: []
      }
      enquiries: {
        Row: {
          contact: string | null
          created_at: string
          id: string
          remarks: string | null
          standard: string
          status: string
          student_name: string
        }
        Insert: {
          contact?: string | null
          created_at?: string
          id?: string
          remarks?: string | null
          standard: string
          status?: string
          student_name: string
        }
        Update: {
          contact?: string | null
          created_at?: string
          id?: string
          remarks?: string | null
          standard?: string
          status?: string
          student_name?: string
        }
        Relationships: []
      }
      exams: {
        Row: {
          class: string
          created_at: string
          exam_date: string
          id: string
          notes: string | null
          section: string | null
          start_time: string | null
          subject: string
        }
        Insert: {
          class: string
          created_at?: string
          exam_date: string
          id?: string
          notes?: string | null
          section?: string | null
          start_time?: string | null
          subject: string
        }
        Update: {
          class?: string
          created_at?: string
          exam_date?: string
          id?: string
          notes?: string | null
          section?: string | null
          start_time?: string | null
          subject?: string
        }
        Relationships: []
      }
      fastag_accounts: {
        Row: {
          bus_id: string
          current_balance: number
          id: string
        }
        Insert: {
          bus_id: string
          current_balance?: number
          id?: string
        }
        Update: {
          bus_id?: string
          current_balance?: number
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fastag_accounts_bus_id_fkey"
            columns: ["bus_id"]
            isOneToOne: true
            referencedRelation: "buses"
            referencedColumns: ["id"]
          },
        ]
      }
      fastag_recharges: {
        Row: {
          amount: number
          bus_id: string
          date: string
          id: string
        }
        Insert: {
          amount: number
          bus_id: string
          date?: string
          id?: string
        }
        Update: {
          amount?: number
          bus_id?: string
          date?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fastag_recharges_bus_id_fkey"
            columns: ["bus_id"]
            isOneToOne: false
            referencedRelation: "buses"
            referencedColumns: ["id"]
          },
        ]
      }
      fees: {
        Row: {
          class: string
          created_at: string
          id: string
          phone: string | null
          remarks: string | null
          student_name: string
          term1_fee: number
          total_paid: number
        }
        Insert: {
          class: string
          created_at?: string
          id?: string
          phone?: string | null
          remarks?: string | null
          student_name: string
          term1_fee?: number
          total_paid?: number
        }
        Update: {
          class?: string
          created_at?: string
          id?: string
          phone?: string | null
          remarks?: string | null
          student_name?: string
          term1_fee?: number
          total_paid?: number
        }
        Relationships: []
      }
      fitness_certificates: {
        Row: {
          bus_id: string
          created_at: string
          expiry_date: string
          fc_number: string | null
          id: string
          image_url: string | null
          issue_date: string | null
          remarks: string | null
        }
        Insert: {
          bus_id: string
          created_at?: string
          expiry_date: string
          fc_number?: string | null
          id?: string
          image_url?: string | null
          issue_date?: string | null
          remarks?: string | null
        }
        Update: {
          bus_id?: string
          created_at?: string
          expiry_date?: string
          fc_number?: string | null
          id?: string
          image_url?: string | null
          issue_date?: string | null
          remarks?: string | null
        }
        Relationships: []
      }
      fuel_logs: {
        Row: {
          bill_image: string | null
          bus_id: string
          cost: number
          date: string
          id: string
          litres: number
          odometer: number | null
        }
        Insert: {
          bill_image?: string | null
          bus_id: string
          cost: number
          date?: string
          id?: string
          litres: number
          odometer?: number | null
        }
        Update: {
          bill_image?: string | null
          bus_id?: string
          cost?: number
          date?: string
          id?: string
          litres?: number
          odometer?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "fuel_logs_bus_id_fkey"
            columns: ["bus_id"]
            isOneToOne: false
            referencedRelation: "buses"
            referencedColumns: ["id"]
          },
        ]
      }
      gas_logs: {
        Row: {
          cost: number
          cylinders: number
          date: string
          id: string
        }
        Insert: {
          cost: number
          cylinders: number
          date?: string
          id?: string
        }
        Update: {
          cost?: number
          cylinders?: number
          date?: string
          id?: string
        }
        Relationships: []
      }
      homework: {
        Row: {
          class: string
          created_at: string
          created_by: string | null
          description: string | null
          due_date: string | null
          id: string
          section: string
          subject: string
          title: string
        }
        Insert: {
          class: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          section: string
          subject: string
          title: string
        }
        Update: {
          class?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          section?: string
          subject?: string
          title?: string
        }
        Relationships: []
      }
      homework_completion: {
        Row: {
          completed: boolean
          completed_at: string
          homework_id: string
          id: string
          proof_url: string | null
          student_id: string
        }
        Insert: {
          completed?: boolean
          completed_at?: string
          homework_id: string
          id?: string
          proof_url?: string | null
          student_id: string
        }
        Update: {
          completed?: boolean
          completed_at?: string
          homework_id?: string
          id?: string
          proof_url?: string | null
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "homework_completion_homework_id_fkey"
            columns: ["homework_id"]
            isOneToOne: false
            referencedRelation: "homework"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "homework_completion_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      kitchen_items: {
        Row: {
          id: string
          name: string
          stock: number
          unit: string
        }
        Insert: {
          id?: string
          name: string
          stock?: number
          unit?: string
        }
        Update: {
          id?: string
          name?: string
          stock?: number
          unit?: string
        }
        Relationships: []
      }
      kitchen_purchases: {
        Row: {
          cost: number
          date: string
          id: string
          item_id: string | null
          item_name: string
          qty: number
        }
        Insert: {
          cost: number
          date?: string
          id?: string
          item_id?: string | null
          item_name: string
          qty: number
        }
        Update: {
          cost?: number
          date?: string
          id?: string
          item_id?: string | null
          item_name?: string
          qty?: number
        }
        Relationships: [
          {
            foreignKeyName: "kitchen_purchases_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "kitchen_items"
            referencedColumns: ["id"]
          },
        ]
      }
      marks: {
        Row: {
          exam: string
          id: string
          max_score: number
          recorded_at: string
          score: number
          student_id: string
          subject: string
        }
        Insert: {
          exam: string
          id?: string
          max_score?: number
          recorded_at?: string
          score: number
          student_id: string
          subject: string
        }
        Update: {
          exam?: string
          id?: string
          max_score?: number
          recorded_at?: string
          score?: number
          student_id?: string
          subject?: string
        }
        Relationships: [
          {
            foreignKeyName: "marks_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      parent_child_links: {
        Row: {
          created_at: string
          id: string
          parent_id: string
          roll_number: string
          status: Database["public"]["Enums"]["link_status"]
        }
        Insert: {
          created_at?: string
          id?: string
          parent_id: string
          roll_number: string
          status?: Database["public"]["Enums"]["link_status"]
        }
        Update: {
          created_at?: string
          id?: string
          parent_id?: string
          roll_number?: string
          status?: Database["public"]["Enums"]["link_status"]
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          id: string
          identifier: string
          identifier_type: Database["public"]["Enums"]["identifier_type"]
          name: string
          status: Database["public"]["Enums"]["user_status"]
        }
        Insert: {
          created_at?: string
          id: string
          identifier: string
          identifier_type: Database["public"]["Enums"]["identifier_type"]
          name: string
          status?: Database["public"]["Enums"]["user_status"]
        }
        Update: {
          created_at?: string
          id?: string
          identifier?: string
          identifier_type?: Database["public"]["Enums"]["identifier_type"]
          name?: string
          status?: Database["public"]["Enums"]["user_status"]
        }
        Relationships: []
      }
      remarks: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          remark: string
          student_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          remark: string
          student_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          remark?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "remarks_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      routes: {
        Row: {
          id: string
          route_name: string
          toll_cost: number
        }
        Insert: {
          id?: string
          route_name: string
          toll_cost?: number
        }
        Update: {
          id?: string
          route_name?: string
          toll_cost?: number
        }
        Relationships: []
      }
      staff_attendance: {
        Row: {
          category: string
          created_at: string
          date: string
          id: string
          in_time: string | null
          out_time: string | null
          role: string | null
          staff_name: string
          status: string
        }
        Insert: {
          category?: string
          created_at?: string
          date?: string
          id?: string
          in_time?: string | null
          out_time?: string | null
          role?: string | null
          staff_name: string
          status?: string
        }
        Update: {
          category?: string
          created_at?: string
          date?: string
          id?: string
          in_time?: string | null
          out_time?: string | null
          role?: string | null
          staff_name?: string
          status?: string
        }
        Relationships: []
      }
      stock_items: {
        Row: {
          category: string
          created_at: string
          id: string
          name: string
          quantity: number
          remarks: string | null
          unit: string | null
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          name: string
          quantity?: number
          remarks?: string | null
          unit?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          name?: string
          quantity?: number
          remarks?: string | null
          unit?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      students: {
        Row: {
          class: string
          created_at: string
          id: string
          name: string
          roll_number: string
          section: string
          user_id: string | null
        }
        Insert: {
          class: string
          created_at?: string
          id?: string
          name: string
          roll_number: string
          section: string
          user_id?: string | null
        }
        Update: {
          class?: string
          created_at?: string
          id?: string
          name?: string
          roll_number?: string
          section?: string
          user_id?: string | null
        }
        Relationships: []
      }
      teacher_attendance: {
        Row: {
          created_at: string
          date: string
          id: string
          in_time: string | null
          out_time: string | null
          status: string
          teacher_id: string
        }
        Insert: {
          created_at?: string
          date?: string
          id?: string
          in_time?: string | null
          out_time?: string | null
          status?: string
          teacher_id: string
        }
        Update: {
          created_at?: string
          date?: string
          id?: string
          in_time?: string | null
          out_time?: string | null
          status?: string
          teacher_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      current_status: {
        Args: never
        Returns: Database["public"]["Enums"]["user_status"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role:
        | "admin"
        | "principal"
        | "teacher"
        | "student"
        | "parent"
        | "pending"
        | "chairman"
      identifier_type: "roll" | "phone" | "email"
      link_status: "pending" | "approved" | "rejected"
      user_status: "pending" | "approved" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "principal",
        "teacher",
        "student",
        "parent",
        "pending",
        "chairman",
      ],
      identifier_type: ["roll", "phone", "email"],
      link_status: ["pending", "approved", "rejected"],
      user_status: ["pending", "approved", "rejected"],
    },
  },
} as const
