import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { RoleGuard } from "@/components/RoleGuard";
import AppLayout from "@/components/AppLayout";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Chairman from "./pages/Chairman";
import Academic from "./pages/Academic";
import Transport from "./pages/Transport";
import BusDetail from "./pages/BusDetail";
import Attendance from "./pages/Attendance";
import EB from "./pages/EB";
import Kitchen from "./pages/Kitchen";
import Admin from "./pages/Admin";
import Admissions from "./pages/Admissions";
import Enquiries from "./pages/Enquiries";
import Fees from "./pages/Fees";
import Stock from "./pages/Stock";
import NotFound from "./pages/NotFound.tsx";
import { useAuth } from "@/contexts/AuthContext";

const queryClient = new QueryClient();

const Protected = ({ children, allowed }: any) => (
  <RoleGuard allowed={allowed}><AppLayout>{children}</AppLayout></RoleGuard>
);

const Home = () => {
  const { primaryRole } = useAuth();
  return primaryRole === "chairman" ? <Chairman /> : <Dashboard />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route path="/" element={<Protected><Home /></Protected>} />
            <Route path="/academic" element={<Protected><Academic /></Protected>} />
            <Route path="/transport" element={<Protected allowed={["admin","principal","chairman"]}><Transport /></Protected>} />
            <Route path="/transport/bus/:id" element={<Protected allowed={["admin","principal","chairman"]}><BusDetail /></Protected>} />
            <Route path="/attendance" element={<Protected allowed={["admin","principal","teacher"]}><Attendance /></Protected>} />
            <Route path="/eb" element={<Protected allowed={["admin","principal","chairman"]}><EB /></Protected>} />
            <Route path="/kitchen" element={<Protected allowed={["admin","principal","chairman"]}><Kitchen /></Protected>} />
            <Route path="/admissions" element={<Protected allowed={["admin","principal","chairman"]}><Admissions /></Protected>} />
            <Route path="/enquiries" element={<Protected allowed={["admin","principal","chairman"]}><Enquiries /></Protected>} />
            <Route path="/fees" element={<Protected allowed={["admin","principal","chairman"]}><Fees /></Protected>} />
            <Route path="/stock" element={<Protected allowed={["admin","principal","chairman"]}><Stock /></Protected>} />
            <Route path="/admin" element={<Protected allowed={["admin"]}><Admin /></Protected>} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
